/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel DOT   *
 *   jeannoeldot@club-internet.fr   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#include "cpreference.h"

CPreference::CPreference(QWidget* parent, Qt::WFlags fl)
: QDialog( parent, fl ), Ui::DlgPreference()
{
	setupUi(this);

	RBtJoueur->setChecked( TRUE );
	RBtOrdi->setChecked( FALSE );

	RBtBlanc->setChecked( TRUE );
	RBtNoir->setChecked( FALSE );

	RBtFaible->setChecked( FALSE );
	RBtMoyen->setChecked( FALSE );
	RBtEleve->setChecked( TRUE );
}

CPreference::CPreference( NOMJOUEUR commence, COULEURBOULE couleur, NIVEAUJEU niveau, QWidget* parent, Qt::WFlags fl )
: QDialog( parent, fl ), Ui::DlgPreference()
{
	setupUi(this);

	m_commence = commence;
	m_couleur = couleur;
	m_niveau = niveau;
	setValeur( m_commence, m_couleur, m_niveau );
}

CPreference::~CPreference()
{
}

void CPreference::setCommence( NOMJOUEUR commence )
{
	m_commence = commence;
	setValeur( commence, m_couleur, m_niveau );
}
void CPreference::setCouleur( COULEURBOULE couleur )
{
	m_couleur = couleur;
	setValeur( m_commence, couleur, m_niveau );
}
void CPreference::setNiveau( NIVEAUJEU niveau )
{
	m_niveau = niveau;
	setValeur( m_commence, m_couleur, niveau );
}

void CPreference::setValeur( NOMJOUEUR commence, COULEURBOULE couleur, NIVEAUJEU niveau )
{
	switch( commence )
	{
		case( HUMAIN ):
		RBtJoueur->setChecked( TRUE );
		RBtOrdi->setChecked( FALSE );
		break;
		case( ORDI ):
		RBtJoueur->setChecked( FALSE );
		RBtOrdi->setChecked( TRUE );
		break;
		case( PERSONNE ):
		break;
	}

	switch( couleur )
	{
		case( BLANC ):
			RBtBlanc->setChecked( TRUE );
			RBtNoir->setChecked( FALSE );
			break;
		case( NOIR ):
			RBtBlanc->setChecked( FALSE );
			RBtNoir->setChecked( TRUE );
			break;
	}

	switch( niveau )
	{
		case( FAIBLE ):
			RBtFaible->setChecked( TRUE );
			RBtMoyen->setChecked( FALSE );
			RBtEleve->setChecked( FALSE );
			break;
		case( MOYEN ):
			RBtFaible->setChecked( FALSE );
			RBtMoyen->setChecked( TRUE );
			RBtEleve->setChecked( FALSE );
			break;
		case( FORT ):
			RBtFaible->setChecked( FALSE );
			RBtMoyen->setChecked( FALSE );
			RBtEleve->setChecked( TRUE );
			break;
	}
}

/*$SPECIALIZATION$*/
void CPreference::reject()
{
  QDialog::reject();
}

void CPreference::accept()
{
	if(TRUE == RBtJoueur->isChecked())	m_commence = HUMAIN;
	if(TRUE == RBtOrdi->isChecked())	m_commence = ORDI;

	if(TRUE == RBtBlanc->isChecked())	m_couleur = BLANC;
	if(TRUE == RBtNoir->isChecked())	m_couleur = NOIR;

	if(TRUE == RBtFaible->isChecked())	m_niveau = FAIBLE;
	if(TRUE == RBtMoyen->isChecked())	m_niveau = MOYEN;
	if(TRUE == RBtEleve->isChecked())	m_niveau = FORT;

  QDialog::accept();
}



