<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>CAligne5</name>
    <message>
        <location filename="caligne5.cpp" line="78"/>
        <source>POINTS JOUEUR : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="90"/>
        <source>POINTS ORDI : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="102"/>
        <source>NIVEAU : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="304"/>
        <source> - Jouer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="307"/>
        <source>Partie en cours...

Faire d&apos;abord Menu Jeu : Arr&#xc3;&#xaa;ter ou F5
et ensuite Menu Jeu : Jouer ou F2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="346"/>
        <source>Jouer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="347"/>
        <source>F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="348"/>
        <source>D&#xc3;&#xa9;buter une partie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="457"/>
        <source>Arr&#xc3;&#xaa;ter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="352"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="353"/>
        <source>Arr&#xc3;&#xaa;ter une partie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="356"/>
        <source>&amp;Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="357"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="358"/>
        <source>Quitter Aligne5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="361"/>
        <source>&amp;Pr&#xc3;&#xa9;f&#xc3;&#xa9;rences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="362"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="363"/>
        <source>Choisir les pr&#xc3;&#xa9;f&#xc3;&#xa9;rences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="366"/>
        <source>Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="367"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="368"/>
        <source>Affiche l&apos;aide de Aligne5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="371"/>
        <source>&amp;&#xc3;&#x80; Propos de : Aligne5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="373"/>
        <source>&#xc3;&#x80; Propos de : Aligne5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="378"/>
        <source>&#xc3;&#x80; Propos de Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="388"/>
        <source>&amp;Jeu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="394"/>
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="397"/>
        <source>&amp;Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="416"/>
        <source>Pr&#xc3;&#xaa;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="425"/>
        <source>&#xc3;&#x80; propos de </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="439"/>
        <source> - Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="442"/>
        <source>Il faut aligner 5 boules
de la m&#xc3;&#xaa;me couleur et c&apos;est gagn&#xc3;&#xa9;!

(Pour tricher : bouton droit)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="453"/>
        <source> - Arr&#xc3;&#xaa;ter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="454"/>
        <source> Arr&#xc3;&#xaa;ter la partie en cours ? 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="501"/>
        <source>Continuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="499"/>
        <source> - Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="503"/>
        <source>Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="518"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="530"/>
        <source> - Fermer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="531"/>
        <source> Fermer le jeu Aligne5 ? </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="532"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="534"/>
        <source>Fermer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="785"/>
        <source>D&#xc3;&#xa9;but de la partie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="795"/>
        <source>Fin de la partie...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="805"/>
        <source>JOUEUR JOUE...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="815"/>
        <source>ORDI JOUE...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="825"/>
        <source>ORDI &#xc3;&#x80; GAGN&#xc3;&#x89;!!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="835"/>
        <source>POINTS JOUEUR : %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="846"/>
        <source>POINTS ORDI : %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="857"/>
        <source>NIVEAU : %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="866"/>
        <source>Fermer le jeu?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="430"/>
        <source>&lt;h2&gt;%1 %2&lt;/h2&gt;&lt;p&gt;Simple petit jeu de logique...&lt;p&gt;Copyright @ 2007 JND-Software inc.&lt;p&gt;Ce programme est distribu&#xc3;&#xa9; selon les termes de la GPL v2.&lt;p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="500"/>
        <source> Quitter le jeu %1 ? 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="775"/>
        <source>Pour jouer, menu Jeu : Jouer ou F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="901"/>
        <source>ALIGNE5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="904"/>
        <source>Pour jouer, menu Jeu : Jouer
ou appuyer sur F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="909"/>
        <source>PARTIE GAGN&#xc3;&#x89;E PAR
ORDINATEUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="912"/>
        <source>PARTIE GAGN&#xc3;&#x89;E PAR
JOUEUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="caligne5.cpp" line="915"/>
        <source>PARTIE &#xc3;&#x80; &#xc3;&#x89;GALIT&#xc3;&#x89;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPreference</name>
    <message>
        <location filename="dlgpreference.ui" line="32"/>
        <source>Qui Commence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="49"/>
        <source>     JOUEUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="76"/>
        <source>     ORDINATEUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="91"/>
        <source>Couleur Boule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="150"/>
        <source>Niveau Jeu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="531"/>
        <source>     FAIBLE       </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="913"/>
        <source>     MOYEN      </source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="dlgpreference.ui" line="1295"/>
        <source>     ELEVÉ       </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="1310"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="1323"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="dlgpreference.ui" line="13"/>
        <source>Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="108"/>
        <source>     CREME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dlgpreference.ui" line="135"/>
        <source>     NOIRE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
