/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel DOT   *
 *   jeannoeldot@club-internet.fr   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef CALIGNE5_H
#define CALIGNE5_H

#include <QMainWindow>

#include "constante.h"
#include "enumeration.h"

/**
	@author Jean-Noel DOT <jeannoeldot@club-internet.fr>
*/

class QAction;
class QMenu;
class QLabel;
class CJeu;
class SDLPlayer;

class CAligne5 : public QMainWindow
{
Q_OBJECT
public:
    CAligne5();

    ~CAligne5();

private:
	void createActions();
	void createMenus();
	void createStatusBar();
	void loadImage(const QString &fileName, QImage *image);
	void afficherImageDebutJeu();
	void clicBoutonGauche();
	void OrdiJoue();
	void clicBoutonDroit();
	void cloturePartie( const CODEFIN codefin );
	void afficheBouleOrdi( const QRect r, const COULEURBOULE couleurboule );
	void afficheUneBoule( const QRect r, const COULEURBOULE couleurboule );
	void afficherMsgDebuterJeu();
	void afficherMsgDebutPartie();
	void afficherMsgFinPartie();
	void afficherMsgJoueurJoue();
	void afficherMsgNbPointJoueur();
	void afficherMsgNbPointOrdi();
	void afficherMsgOrdiJoue();
	void afficherStatusBar();
	void afficherMsgNiveauJeu();
	void afficherImageFinJeu();
	void afficherImageLabel();
	void afficherMsgOrdiGagne();
	void afficherMsgFermerAppli();
	void faitTemporisation();
	void faitClignoter( const QRect r, const COULEURBOULE couleurboule );
	void dessineUneBoule( const QRect r, const COULEURBOULE couleurboule );
    void ecrireMsgFinJeu( const CODEFIN codefin );

private:
	QMenu *m_jeuMenu;
	QMenu *m_optionsMenu;
	QMenu *m_aideMenu;

	QAction *m_aboutAct;
	QAction *m_aideAct;
	QAction *m_arretpartieAct;
	QAction *m_debutpartieAct;
	QAction *m_preferenceAct;
	QAction *m_quitterAct;
	QAction *m_aboutQtAct;

	QLabel	*m_imageLabel;

	QLabel *m_pLabel0;
	QLabel *m_pLabel1;
	QLabel *m_pLabel2;

	int		m_heightMenuBar;
	QString	m_messagestatusbar;
	QSize		resultSize;

	QImage	m_imgMemPlateau;
	QImage	m_imgPlateau;
	QPixmap	m_pmMemPlateau;
	QImage	m_imgCopie;

	QImage	m_imgFinJeu;
	QImage	m_imgDebutJeu;
	QImage	m_imgDessinBoule;

	bool		m_fPartie;
	CJeu		*m_pcJeu;
	int		m_posClicX;
	int		m_posClicY;

	SDLPlayer	*mySDLPlayer;

private slots:
    void slotAbout();
    void slotAide();
    void slotArretPartie();
    void slotDebutPartie();
    void slotPreferences();
    void slotQuitterProg();
    void slotAboutQt();
protected:
    void mouseReleaseEvent( QMouseEvent *e );
    void closeEvent( QCloseEvent *e );
};

#endif
