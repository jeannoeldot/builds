/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel DOT   *
 *   jeannoeldot@club-internet.fr   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef CONSTANTE_H
#define CONSTANTE_H

const int W_PLATEAU = 512;
const int H_PLATEAU = 384;

const int X_DEBUTJEU = 78;
const int Y_DEBUTJEU = 14;
const int W_DEBUTJEU = 356;
const int H_DEBUTJEU = 357;

const int X_FINJEU = 78;
const int Y_FINJEU = 14;
const int W_FINJEU = 356;
const int H_FINJEU = 357;

const int W_DESSINBOULE = 120;
const int H_DESSINBOULE = 30;
const int INCX_BOULE = 30;
const int WH_BOULE = 22;


const int X_TROUS = 89;
const int Y_TROUS = 24;
const int W_TROUS = 336;
const int H_TROUS = 336;


const int TEMPOFORT = 500;				/// en millisecondes
const int TEMPOMOYEN = 1000;
const int TEMPOFAIBLE = 1500;
const int NBFOISFORT = 3;				/// pour clignotement
const int NBFOISMOYEN = 5;
const int NBFOISFAIBLE = 7;
const int TEMPSHOW = 200;
const int TEMPHIDE = 100;


const int X_RECTCASE = 97;
const int Y_RECTCASE = 33;
const int WH_RECT = 22;
const int INCX_RECT = 33;
const int INCY_RECT = 33;

const int HV_NBRECT = 10;
const int NBRECT = 100;


const int SIZEDIFF = 8;

const int DIFF_FAIBLE[SIZEDIFF] = {1,2,3,4,5,8,20,50};
const int DIFF_MOYEN[SIZEDIFF] = {1,2,4,6,10,20,40,100};
const int DIFF_FORT[SIZEDIFF] = {1,2,10,20,100,200,1000,5000};



#endif
