/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel DOT   *
 *   jeannoeldot@club-internet.fr   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "cordi.h"

COrdi::COrdi()
 : CJoueur()
{
}

COrdi::COrdi( COULEURBOULE couleur, int nbpoint )
 : CJoueur()
{
	m_CouleurBoule = couleur;
	m_NbPoint = nbpoint;
}

COrdi::~COrdi()
{
}

CODEFIN COrdi::ordiJoue( quint8 aCases[], int aDifficulte[] )
{
	CODEFIN code;
	for( int i = 0; i < NBRECT; i++ )
	{
		m_acasejeu[i] = aCases[i];
	}
	for( int i = 0; i < SIZEDIFF; i++ )
	{
		m_adifficulte[i] = aDifficulte[i];
	}

	m_quiJoue = ORDI;
	razTableauNote();
	bool gagne = FALSE;
	if( gagne == FALSE )	testLigne();
	if( m_quiGagne == ORDI )	gagne = TRUE;
	if( gagne == FALSE )	testColonne();
	if( m_quiGagne == ORDI )	gagne = TRUE;
	if( gagne == FALSE )	testSens1();
	if( m_quiGagne == ORDI )	gagne = TRUE;
	if( gagne == FALSE )	testSens2();
	if( m_quiGagne == ORDI ) 	gagne = TRUE;
	if( gagne == TRUE )
	{
		code = ORDIFIN;
	}
	else
	{
		if( m_notemaxi == 0 )	///Partie Nulle
		{
			code = PARTIENULLE;
		}
		else
		{
			code = CONTINUE;
		}
	}
	return code;
}
