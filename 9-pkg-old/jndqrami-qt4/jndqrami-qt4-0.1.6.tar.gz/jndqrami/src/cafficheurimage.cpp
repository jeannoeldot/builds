/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jeannoeldot@club-internet.fr   *
 *                                                                         *
 ***************************************************************************/

#include "cafficheurimage.h"

CAfficheurImage::CAfficheurImage(QWidget *parent)
 : QWidget(parent)
{
	setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
}

CAfficheurImage::CAfficheurImage( QWidget *parent, int w, int h )
 : QWidget(parent)
{
	m_w = w;
	m_h = h;
	setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
}

CAfficheurImage::~CAfficheurImage()
{
}


/*!
    \fn CAfficheurImage::paintEvent(QPaintEvent *event)
 */
void CAfficheurImage::paintEvent(QPaintEvent * /*event*/)
{
	QPainter painter( this );
	painter.drawImage( QPoint(0, 0), m_image );
}


/*!
    \fn CAfficheurImage::sizeHint() const
 */
QSize CAfficheurImage::sizeHint() const
{
	return QSize(m_w, m_h);
}


/*!
    \fn CAfficheurImage::afficherImage(const QImage &image)
 */
void CAfficheurImage::afficherImage(const QImage &image)
{
	m_image = image;
	update();
}


/*!
    \fn CAfficheurImage::setImage( const QImage &image )
 */
void CAfficheurImage::setImage( const QImage &image )
{
	m_image = image;
}
