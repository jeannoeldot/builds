/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#ifndef CSTATISTIQUE_H
#define CSTATISTIQUE_H

#include <QDialog>
#include <QList>

class QPushButton;
class QTableWidget;
class CResultat;

/**
	@author Jean-Noel Dot <jeannoeldot@club-internet.fr>
*/
class CStatistique : public QDialog
{
    Q_OBJECT

public:
    CStatistique( QList<CResultat> *qlresultats, int nbjoueurs, QWidget *parent = 0 );

    ~CStatistique();

private:
  void addRows();

  QList<CResultat> *m_qlresultats;
  int m_nbjoueurs;
  QPushButton *m_okButton;
  QTableWidget *m_tableWidget;
  int m_widthItem;

};

#endif
