/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jeannoeldot@club-internet.fr   *
 *                                                                         *
 ***************************************************************************/

#ifndef CAFFICHEURIMAGE_H
#define CAFFICHEURIMAGE_H

#include <QWidget>
#include <QPainter>

class CAfficheurImage : public QWidget
{
Q_OBJECT
public:
    CAfficheurImage(QWidget *parent = 0);
    CAfficheurImage(QWidget *parent = 0, int w = 0, int h = 0 );

    ~CAfficheurImage();

    QSize sizeHint() const;
    void afficherImage(const QImage &image);
    void setImage( const QImage &image );

protected:
    void paintEvent(QPaintEvent *event);

private:
	QImage	m_image;
	int 	m_w;
	int	m_h;

};

#endif
