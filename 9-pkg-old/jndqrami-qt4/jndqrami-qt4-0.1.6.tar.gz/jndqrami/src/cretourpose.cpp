/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#include "cretourpose.h"

CRetourPose::CRetourPose()
{
  m_isOk = false;
  m_nbcartesjeu = -1;
  m_indexcpj = -1;
}


CRetourPose::~CRetourPose()
{
}




/*!
    \fn CRetourPose::setIndexCpj( const int index )
 */
void CRetourPose::setIndexCpj( const int index )
{
  m_indexcpj = index;
}


/*!
    \fn CRetourPose::setIsOk( const bool ok )
 */
void CRetourPose::setIsOk( const bool ok )
{
  m_isOk = ok;
}


/*!
    \fn CRetourPose::setNombreCartesJeu( const int nbcartes )
 */
void CRetourPose::setNombreCartesJeu( const int nbcartes )
{
  m_nbcartesjeu = nbcartes;
}


/*!
    \fn CRetourPose::isOk()
 */
bool CRetourPose::isOk()
{
  return m_isOk;
}


/*!
    \fn CRetourPose::nombreCartesJeu()
 */
int CRetourPose::nombreCartesJeu()
{
  return m_nbcartesjeu;
}


/*!
    \fn CRetourPose::indexDansCpj()
 */
int CRetourPose::indexDansCpj()
{
  return m_indexcpj;
}
