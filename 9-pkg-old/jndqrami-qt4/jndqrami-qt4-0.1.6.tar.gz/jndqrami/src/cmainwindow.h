/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#ifndef CMAINWINDOW_H
#define CMAINWINDOW_H

#include <QMainWindow>

class QAction;
class QMenu;

class CRami;
class CHelpBrowser;

/**
	@author Jean-Noel Dot <jeannoeldot@club-internet.fr>
*/
class CMainWindow : public QMainWindow
{
	Q_OBJECT

public:
    CMainWindow( const int w_ecran, const int h_ecran );

    ~CMainWindow();
    
protected:
	void closeEvent( QCloseEvent *event );

private:
	void createActions();
	void createMenus();
	void createStatusBar();
	
  void readSettings();
  void writeSettings();
	
  void afficherStatusBar();
  bool testerSiPartieEnCours();
  void setPreferences();

	QMenu *m_jeuMenu;
	QMenu *m_optionsMenu;
	QMenu *m_aideMenu;

	QAction *m_debutjeu2Act;
	QAction *m_debutjeu3Act;
	QAction *m_debutjeu4Act;
	QAction *m_arretpartieAct;
	QAction *m_quitterAct;
	QAction *m_preferenceAct;
  QAction *m_statistiqueAct; 
	QAction *m_aideAct;
	QAction *m_aboutAct;
	QAction *m_aboutQtAct;

	int		m_heightMenuBar;
	int		m_heightStatusBar;
	QString	m_messagestatusbar;
  QPoint m_pos;
  
	CRami		*m_pcrami;
 CHelpBrowser *m_pchelpbrowser; 
  
  int m_nbjoueurs;

  bool m_f_animecarte;
  bool m_f_son;
  int m_niveaujeu;
  int m_vitesse;
  int m_volume;

private slots:
    void slotDebutJeu2();
    void slotDebutJeu3();
    void slotDebutJeu4();
    void slotArretPartie();
    void slotQuitterProg();
    void slotPreferences();
    void slotStatistiques();
    void slotAide();
    void slotAbout();
    void slotAboutQt();
public slots:
    void afficherMsgStatusBar();
};

#endif
