<!DOCTYPE TS><TS>
<context>
    <name>CHelpBrowser</name>
    <message>
        <source>&amp;D&#xc3;&#xa9;but</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Retour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fermer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aide : %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CMainWindow</name>
    <message>
        <source> - Jouer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partie en cours...

Faire d&apos;abord Menu Jeu : Arr&#xc3;&#xaa;ter ou F5
et ensuite Menu Jeu : Jouer ou F2, F3, F4
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Arr&#xc3;&#xaa;ter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Arr&#xc3;&#xaa;ter la partie en cours ? 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arr&#xc3;&#xaa;ter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Quitter le jeu Rami ? 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&#xc3;&#x80; propos de </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;h2&gt;Rami 0.1&lt;/h2&gt;&lt;p&gt;Simple petit jeu de cartes...&lt;p&gt;Copyright @ 2007-2008 JND-Software Inc.&lt;p&gt;Ce programme est distribu&#xc3;&#xa9; selon les termes de la GPL v2.&lt;p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fermer le jeu?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Fermer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Fermer le jeu Rami ? </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fermer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Joueurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&#xc3;&#xa9;buter une partie &#xc3;&#xa0; 2 Joueurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3 Joueurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&#xc3;&#xa9;buter une partie &#xc3;&#xa0; 3 Joueurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4 Joueurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&#xc3;&#xa9;buter une partie &#xc3;&#xa0; 4 Joueurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arr&#xc3;&#xaa;ter la partie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quitter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quitter Rami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Pr&#xc3;&#xa9;f&#xc3;&#xa9;rences...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choisir les pr&#xc3;&#xa9;f&#xc3;&#xa9;rences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Statistiques...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Afficher les statistiques</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Affiche l&apos;aide de Rami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;&#xc3;&#x80; Propos de : Rami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&#xc3;&#x80; Propos de : Rami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&#xc3;&#x80; Propos de Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Jeu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pr&#xc3;&#xaa;t</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CRami</name>
    <message>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&#xc3;&#x80; joueur SUD de jouer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&#xc3;&#xa9;but d&apos;une partie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fin d&apos;une partie.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SUD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NORD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OUEST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> A GAGN&#xc3;&#x89; !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fin d&apos;une partie. Cliquer pour continuer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S : Gagn&#xc3;&#xa9;e=%1  P&#xc3;&#xa9;nalit&#xc3;&#xa9;=%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N : Gagn&#xc3;&#xa9;e=%1  P&#xc3;&#xa9;nalit&#xc3;&#xa9;=%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E : Gagn&#xc3;&#xa9;e=%1  P&#xc3;&#xa9;nalit&#xc3;&#xa9;=%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O : Gagn&#xc3;&#xa9;e=%1  P&#xc3;&#xa9;nalit&#xc3;&#xa9;=%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source></source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Erreur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ORDI JOUE

carte == ERREUR_CARTE.

Rami va QUITTER!!!

D&#xc3;&#x89;SOL&#xc3;&#x89;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EST joue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ORDI

 a pris carte jet&#xc3;&#xa9;e.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ORDI

 a pos&#xc3;&#xa9;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ORDI

 a pos&#xc3;&#xa9; 1 carte.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ORDI

 a pioch&#xc3;&#xa9;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ORDI

 a jet&#xc3;&#xa9; 1 carte.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NORD joue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OUEST joue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Une tierce est n&#xc3;&#xa9;cessaire pour poser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>51 points sont n&#xc3;&#xa9;cessaires pour poser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ensemble de cartes &#xc3;&#xa0; poser non conforme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La carte prise doit figurer dans les cartes &#xc3;&#xa0; poser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aucun emplacement pour poser cette carte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Il faut piocher ou prendre la carte jet&#xc3;&#xa9;e avant de poser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Il faut d&#xc3;&#xa9;j&#xc3;&#xa0; avoir pos&#xc3;&#xa9; avant de poser 1 carte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La derni&#xc3;&#xa8;re carte est &#xc3;&#xa0; jeter pour terminer la partie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Erreur inconnue...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CStatistique</name>
    <message>
        <source>SUD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NORD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OUEST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rami - R&#xc3;&#xa9;sultats Parties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message encoding="UTF-8">
        <source>Insérer Cartes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COEUR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> 1          2          3           4          5           6          7          8           9          10        11         12         13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  AS         2           3          4          5           6          7          8           9          10        V           D           R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PIQUE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CARREAU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TREFLE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>DlgPreferences</name>
    <message encoding="UTF-8">
        <source>Rami - Préférences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animation Carte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Niveau Joueurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vitesse Jeu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bruitage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animation Carte.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>- Animation pour carte piochée.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>- Animation pour carte prise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <source>- Animation pour carte jetée.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Niveau Faible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Niveau Moyen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Niveau Fort.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vitesse Lente.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vitesse Normale.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vitesse Rapide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bruitages quand Joueurs jouent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
