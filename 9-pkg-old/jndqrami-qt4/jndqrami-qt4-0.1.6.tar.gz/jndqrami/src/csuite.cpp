/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/


#include "csuite.h"

CSuite::CSuite()
{
  m_nbpoints = 0;
  m_nbcartes = 0;
  m_index1c = -1;
  m_couleur = -1;
}

CSuite::CSuite( const int nbcartes, const int nbpoints )
{
  m_nbpoints = nbpoints;
  m_nbcartes = nbcartes;
}

CSuite::~CSuite()
{
}




/*!
    \fn CSuite::setNombrePoints( const int nbpoints )
 */
void CSuite::setNombrePoints( const int nbpoints )
{
  m_nbpoints = nbpoints;
}


/*!
    \fn CSuite::setNombreCartes( const int nbcartes )
 */
void CSuite::setNombreCartes( const int nbcartes )
{
  m_nbcartes = nbcartes;
}


/*!
    \fn CSuite::setIndex1ereCarte( const int index )
 */
void CSuite::setIndex1ereCarte( const int index )
{
  m_index1c = index;
}


/*!
    \fn CSuite::nombrePoints()
 */
int CSuite::nombrePoints()
{
  return m_nbpoints;
}


/*!
    \fn CSuite::nombreCartes()
 */
int CSuite::nombreCartes()
{
  return m_nbcartes;
}


/*!
    \fn CSuite::index1ereCarte()
 */
int CSuite::index1ereCarte()
{
  return m_index1c;
}


/*!
    \fn CSuite::couleur()
 */
int CSuite::couleur()
{
  return m_couleur;
}


/*!
    \fn CSuite::setCouleur( const int couleur )
 */
void CSuite::setCouleur( const int couleur )
{
  m_couleur = couleur;
}


/*!
    \fn CSuite::operator == ( const CSuite & autre )
 */
bool CSuite::operator == ( const CSuite & autre )
{
  if( false == isEgal( m_nbcartes, autre.m_nbcartes ) )
    return false;
  if( false == isEgal( m_nbpoints, autre.m_nbpoints ) )
    return false;
  return true;
}


/*!
    \fn CSuite::isEgal( const int une, const int autre )
 */
bool CSuite::isEgal( const int une, const int autre )
{
  return une == autre;
}


/*!
    \fn CSuite::operator + ( const CSuite & autre )
 */
CSuite CSuite::operator + ( const CSuite & autre )
{
  return CSuite( m_nbcartes + autre.m_nbcartes, m_nbpoints + autre.m_nbpoints );
}


/*!
    \fn CSuite::operator - ( const CSuite & autre )
 */
CSuite CSuite::operator - ( const CSuite & autre )
{
  return CSuite( m_nbcartes - autre.m_nbcartes, m_nbpoints - autre.m_nbpoints );
}
