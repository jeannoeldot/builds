/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#include "cmeme.h"

CMeme::CMeme()
{
  m_nbpoints = 0;
  m_nbcartes = 0;
  m_index1erecarte = -1;
  m_index2emecarte = -1;
  m_index3emecarte = -1;
  m_index4emecarte = -1;
}

CMeme::CMeme( const int nbcartes, const int nbpoints )
{
  m_nbpoints = nbpoints;
  m_nbcartes = nbcartes;
}


CMeme::~CMeme()
{
}




/*!
    \fn CMeme::index1ereCarte()
 */
int CMeme::index1ereCarte()
{
  return m_index1erecarte;
}


/*!
    \fn CMeme::index2emeCarte()
 */
int CMeme::index2emeCarte()
{
  return m_index2emecarte;
}


/*!
    \fn CMeme::index3emeCarte()
 */
int CMeme::index3emeCarte()
{
  return m_index3emecarte;
}


/*!
    \fn CMeme::index4emeCarte()
 */
int CMeme::index4emeCarte()
{
  return m_index4emecarte;
}


/*!
    \fn CMeme::nombreCartes()
 */
int CMeme::nombreCartes()
{
  return m_nbcartes;
}


/*!
    \fn CMeme::nombrePoints()
 */
int CMeme::nombrePoints()
{
  return m_nbpoints;
}


/*!
    \fn CMeme::setIndex1ereCarte( const int index1c )
 */
void CMeme::setIndex1ereCarte( const int index1c )
{
  m_index1erecarte = index1c;
}


/*!
    \fn CMeme::setIndex2emeCarte( const int index2c )
 */
void CMeme::setIndex2emeCarte( const int index2c )
{
  m_index2emecarte = index2c;
}


/*!
    \fn CMeme::setIndex3emeCarte( const int index3c )
 */
void CMeme::setIndex3emeCarte( const int index3c )
{
  m_index3emecarte = index3c;
}


/*!
    \fn CMeme::setIndex4emeCarte( const int index4c )
 */
void CMeme::setIndex4emeCarte( const int index4c )
{
  m_index4emecarte = index4c;
}


/*!
    \fn CMeme::setNombreCartes( const int nbcartes )
 */
void CMeme::setNombreCartes( const int nbcartes )
{
  m_nbcartes = nbcartes;
}


/*!
    \fn CMeme::setNombrePoints( const int nbpoints )
 */
void CMeme::setNombrePoints( const int nbpoints )
{
  m_nbpoints = nbpoints;
}


/*!
    \fn CMeme::operator == ( const CMeme & autre )
 */
bool CMeme::operator == ( const CMeme & autre )
{
  if( false == isEgal( m_nbcartes, autre.m_nbcartes ) )
    return false;
  if( false == isEgal( m_nbpoints, autre.m_nbpoints ) )
    return false;
  return true;
}


/*!
    \fn CMeme::isEgal( const int une, const int autre )
 */
bool CMeme::isEgal( const int une, const int autre )
{
  return une == autre;
}


/*!
    \fn CMeme::operator + ( const CMeme & autre )
 */
CMeme CMeme::operator + ( const CMeme & autre )
{
  return CMeme( m_nbcartes + autre.m_nbcartes, m_nbpoints + autre.m_nbpoints );
}


/*!
    \fn CMeme::operator - ( const CMeme & autre )
 */
CMeme CMeme::operator - ( const CMeme & autre )
{
  return CMeme( m_nbcartes - autre.m_nbcartes, m_nbpoints - autre.m_nbpoints );
}
