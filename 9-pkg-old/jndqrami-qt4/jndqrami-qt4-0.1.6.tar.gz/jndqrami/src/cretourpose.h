/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#ifndef CRETOURPOSE_H
#define CRETOURPOSE_H

/**
	@author Jean-Noel Dot <jeannoeldot@club-internet.fr>
*/
class CRetourPose{
public:
    CRetourPose();

    ~CRetourPose();
    void setIndexCpj( const int index );
    void setIsOk( const bool ok );
    void setNombreCartesJeu( const int nbcartes );
    bool isOk();
    int nombreCartesJeu();
    int indexDansCpj();

private:
    bool m_isOk;
    int m_nbcartesjeu;
    int m_indexcpj;
};

#endif
