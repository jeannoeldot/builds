/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#ifndef CVALEURCARTE_H
#define CVALEURCARTE_H

#include <QWidget>

/**
	@author Jean-Noel Dot <jeannoeldot@club-internet.fr>
*/
class CValeurCarte{
public:
    CValeurCarte();

    ~CValeurCarte();
    int couleur();
    int index();
    quint8 valeurCarte();
    void setCouleur( const int couleur );
    void setIndex( const int index );
    void setValeurCarte( const quint8 valeurcarte );

private:
    int m_couleur;
    int m_index;
    int m_valeurcarte;
};

#endif
