/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/

#ifndef MISEAUPOINT_H
#define MISEAUPOINT_H

/// Rajouter // devant #define MISE_AU_POINT
/// ==> NON ACTIF
//#define MISE_AU_POINT


#endif
