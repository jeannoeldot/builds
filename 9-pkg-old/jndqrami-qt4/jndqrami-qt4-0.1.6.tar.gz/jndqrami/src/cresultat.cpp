/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#include "cresultat.h"

CResultat::CResultat()
{
  penaliteSud = 0;
  penaliteEst = 0;
  penaliteNord = 0;
  penaliteOuest = 0;
}


CResultat::~CResultat()
{
}


