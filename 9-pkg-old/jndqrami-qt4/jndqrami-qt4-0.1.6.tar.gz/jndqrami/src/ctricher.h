/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/

#ifndef CTRICHER_H
#define CTRICHER_H

#include <QDialog>
#include "ui_DlgInsererCartes.h"

#include "constantes.h"

class CTricher : public QDialog, private Ui::Dialog
{
  Q_OBJECT

public:
  CTricher(QWidget* parent = 0, Qt::WFlags fl = 0 );
  CTricher( quint8 * aJeu, int nbcartes, QWidget* parent = 0, Qt::WFlags fl = 0 );
  ~CTricher();
  /*$PUBLIC_FUNCTIONS$*/

    quint8 m_aJeu[16];

public slots:
  /*$PUBLIC_SLOTS$*/

protected:
  /*$PROTECTED_FUNCTIONS$*/

protected slots:
  /*$PROTECTED_SLOTS$*/
  virtual void          reject();
  virtual void          accept();

private:
    void copierJeu( quint8 * ajeu );
    void calculerNumCarte( quint8 carte );
    void cocherBoxCoeur( quint8 carte );
    void cocherBoxPique( quint8 carte );
    void cocherBoxCarreau( quint8 carte );
    void cocherBoxTrefle( quint8 carte );
    void initialiser();
    
    int m_icouleur;
    quint8 m_numcarte;
    int m_nbcartes;
};

#endif

