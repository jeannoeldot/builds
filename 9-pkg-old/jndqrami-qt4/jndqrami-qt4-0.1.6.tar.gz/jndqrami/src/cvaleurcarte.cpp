/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#include "cvaleurcarte.h"

CValeurCarte::CValeurCarte()
{
  m_couleur = -1;
  m_index = -1;
  m_valeurcarte = -1;
}


CValeurCarte::~CValeurCarte()
{
}




/*!
    \fn CValeurCarte::couleur()
 */
int CValeurCarte::couleur()
{
  return m_couleur;
}


/*!
    \fn CValeurCarte::index()
 */
int CValeurCarte::index()
{
  return m_index;
}


/*!
    \fn CValeurCarte::valeurCarte()
 */
quint8 CValeurCarte::valeurCarte()
{
  return m_valeurcarte;
}


/*!
    \fn CValeurCarte::setCouleur( const int couleur )
 */
void CValeurCarte::setCouleur( const int couleur )
{
  m_couleur = couleur;
}


/*!
    \fn CValeurCarte::setIndex( const int index )
 */
void CValeurCarte::setIndex( const int index )
{
  m_index = index;
}


/*!
    \fn CValeurCarte::setValeurCarte( const quint8 valeurcarte )
 */
void CValeurCarte::setValeurCarte( const quint8 valeurcarte )
{
  m_valeurcarte = valeurcarte;
}
