/***************************************************************************
 *   Copyright (C) 2007 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/


#include <QApplication>
#include <QSplashScreen>
#include <QTextCodec>
#include <QTranslator>
#include <QLocale>
#include <QDesktopWidget>

#include "cmainwindow.h"

int main(int argc, char *argv[])
{
	Q_INIT_RESOURCE(application);
	QApplication app(argc, argv);
	
  QSplashScreen *splash = new QSplashScreen;
  splash->setPixmap( QPixmap( ":/images/RamiSplash.png" ) );
  splash->show();
  
  int w_ecran = app.desktop()->width();
  int h_ecran = app.desktop()->height();
	
	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));

 	QTranslator appTranslator;
 	appTranslator.load( "jndqrami_" + QLocale::system().name(), ":/trans");
 	app.installTranslator( &appTranslator );

	CMainWindow * mw = new CMainWindow( w_ecran, h_ecran );
	mw->show();
  
  splash->finish( mw );
  delete splash;
  
	return app.exec();
}

