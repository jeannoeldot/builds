/***************************************************************************
 *   Copyright (C) 2008 by Jean-Noel Dot   *
 *   jeannoeldot@club-internet.fr   *
 ***************************************************************************/
#ifndef CRESULTAT_H
#define CRESULTAT_H

/**
	@author Jean-Noel Dot <jeannoeldot@club-internet.fr>
*/
class CResultat{
public:
    CResultat();

    ~CResultat();

  int penaliteSud;
  int penaliteEst;
  int penaliteNord;
  int penaliteOuest;
};

#endif
