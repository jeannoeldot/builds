These weather images are (c) 2003 by Stardock Corporation.  All rights reserved.

Permission:
Stardock gives you permission to distribute these images and or icons freely as long as this permission document is included. 

Allowed Uses:
You may use these images with any Stardock related product (such as creating DesktopX objects or ObjectDock or plugins).

In addition, Stardock licenses this for use with content that is provided free of charge and is not connected to a commercial software product. You may use these images for skins, themes, and other content for freeware software even if it is competitive in nature with Stardock's offerings as long as the copyright notices are included. You may not, however, bundle these images in any way with any software product without Stardock's express permission.

You may use these images in your website or product as long as this permission.txt is linked somewhere along with Stardock's copyright notice with a link to Stardock's homepage: http://www.stardock.com.

Designed Use:
These weather images are designed to provide the various weather conditions reported by weather services. It was created for use with Stardock DesktopX (http://www.desktopx.net) and Stardock ObjectDock (http://www.objectdock.com) both of which allow users to monitor the weather conditions from their desktop.