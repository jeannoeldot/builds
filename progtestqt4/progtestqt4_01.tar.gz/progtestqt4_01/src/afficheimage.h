/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jnd@localhost.localdomain   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef AFFICHEIMAGE_H
#define AFFICHEIMAGE_H

#include <QMainWindow>
#include <QCloseEvent>
#include <QDomElement>
/**
	@author JND <jnd@localhost.localdomain>
*/

class QLabel;
class QAction;
class QMenu;
class QPushButton;
class CVerdict;

class CAfficheurImage;

class SDLPlayer;

class CHelpBrowser;

class CWeatherDay;

class CAfficheImage : public QMainWindow
{
Q_OBJECT
public:
    CAfficheImage();

    ~CAfficheImage();
    
    void setPathData( const QString& path );

private:
	void createActions();
	void createMenus();
	void createStatusBar();
	void loadImage(const QString &fileName, QImage *image, const int width, const int height);
	void afficheUneBoule( const int x, const int y, const int couleur );
	void testRecoitTableau( const int *tableau, int size );
	CVerdict lectureCVerdict();

	CAfficheurImage	*m_afficheurImage;

	SDLPlayer	*mySDLPlayer;
  
  CHelpBrowser *m_pchelpbrowser; 


	int	genererHasard_0_3();
	int	GenereHasard_0_999();
	int genererHasard_0_5();
  int genererHasard_0_48();
    void weatherParseHead( const QDomElement &element );
    void weatherParseLoc( const QDomElement &element );
    void weatherParseCc( const QDomElement &element );
    void weatherParseDayf( const QDomElement &element );
    void weatherParseDay( const QDomElement &element, CWeatherDay &day );
    void weatherParsePart( const QDomElement &element, CWeatherDay &day );
    void weatherParsePart_d( const QDomElement &element, CWeatherDay &day );
    void weatherParsePart_n( const QDomElement &element, CWeatherDay &day );
    void weatherParseWind( const QDomElement &element, QString &wind_s, QString &wind_t );
    void weatherParseBar( const QDomElement &element, QString &bar_r, QString &bar_d );
    void weatherSetDayNum( CWeatherDay *daynum, const CWeatherDay &day );
    void weatherAfficheDayNum( const CWeatherDay *daynum );
    void weatherConvertSuns( QString &suns );
    void weatherConvertSunr( QString &sunr );
    void weatherSetDialogMeteo();
	
	QPixmap		m_pmFinJeu, m_pmPenguin;
	QPixmap		m_pmMemPlateau, m_pmPlateau, m_pmCopie;
	
	QImage m_imgFinJeu;
	QImage m_imgPenguin;
	QImage m_imgDessinBoule;
	QImage m_imgMemPlateau;
	QImage m_imgPlateau;
	QImage m_imgCopie;
	
	QSize resultSize;
	
	QMenu *m_editMenu;
	QMenu *m_fileMenu;
	QMenu	*m_testMenu;
	QMenu *m_helpMenu;

	QAction *m_newAct;
	QAction *m_openAct;
	QAction *m_exitAct;
	QAction *m_cutAct;
	QAction *m_copyAct;
	QAction *m_pasteAct;
	QAction *m_helpAct;
	QAction *m_aboutAct;
	QAction *m_finjeuAct;
	QAction *m_penguinAct;
	QAction *m_dessinbouleAct;
	QAction *m_testsoundAct;
	QAction *m_testdialAct;
	QAction *m_testenvoitableauAct;
  QAction *m_testrapiditeappelfonctionAct;
	QAction *m_testrapiditeaffichageAct;
	QAction *m_testtempoAct;
	QAction *m_clignoteAct;
  QAction *m_testwgetAct;
  QAction *m_testpathAct;
	
	
	QLabel	*m_imageLabel;
	QLabel *m_pLabel0;
	QLabel *m_pLabel1;
	QLabel *m_pLabel2;

	QPushButton *m_btUndo;
	QPushButton *m_btPiocher;
	QPushButton *m_btValider;

	QPushButton *m_pbtConfirmer;

	int		m_heightMenuBar;
	QString		m_fichiersonerreur;
  
	QString m_pathData;
  
/// Variables weather

  QString m_head_ut;
  QString m_head_us;
  QString m_head_up;

  QString m_loc_dnam;
  QString m_loc_sunr;
  QString m_loc_suns;

  QString m_cc_tmp;
  QString m_cc_t;
  QString m_cc_icon;
  QString m_cc_hmid;
  QString m_cc_bar_r;
  QString m_cc_bar_d;
  QString m_cc_wind_s;
  QString m_cc_wind_t;
  
  CWeatherDay *m_day0;
  CWeatherDay *m_day1;
  CWeatherDay *m_day2;
  CWeatherDay *m_day3;
  CWeatherDay *m_day4;

/////////////////////////////

private slots:
    void newFile();
    void openFile();
    void aboutAppli();
    void closeAppli();
    void showPenguin();
    void showFinJeu();
    void showDessinBoule();
    void testSound();
    void copy();
    void paste();
    void cut();
    void helpAppli();
    void showDialTest();
    void testEnvoiTableau();
	void testDisableAction();
    void meilleurChoix();
    void echangePose();
  void  testRapiditeAppelFonction();
    void testRapiditeAffichage();
    void testTemporisation();
    void testClignote();
    void testWget();
    void testPathData();
    
protected:
    void mousePressEvent( QMouseEvent *e );
    void customEvent(QEvent * event);

};

#endif
