/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jnd@localhost.localdomain   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#include "cweatherdlg.h"

CWeatherDlg::CWeatherDlg(QWidget* parent, Qt::WFlags fl)
: QDialog( parent, fl ), Ui::DialogColored()
{
	setupUi(this);
}

CWeatherDlg::~CWeatherDlg()
{
}

/*$SPECIALIZATION$*/
void CWeatherDlg::reject()
{
  QDialog::reject();
}

void CWeatherDlg::accept()
{
  QDialog::accept();
}

/*!
    \fn CWeatherDlg::set_loc_dnam( const QString &dnam )
 */
void CWeatherDlg::set_loc_dnam( const QString &dnam )
{
  loc_dnamLabel->setText( dnam );
}

/*!
    \fn CWeatherDlg::set_loc_sunr( const QString &sunr )
 */
void CWeatherDlg::set_loc_sunr( const QString &sunr )
{
  loc_sunrLabel->setText( sunr );
}

/*!
    \fn CWeatherDlg::set_loc_suns( const QString &suns )
 */
void CWeatherDlg::set_loc_suns( const QString &suns )
{
  loc_sunsLabel->setText( suns );
}

/*!
    \fn CWeatherDlg::set_cc_wind_s( const QString &s)
 */
void CWeatherDlg::set_cc_wind_s( const QString &s)
{
  cc_wind_sLabel->setText( s );
}

/*!
    \fn CWeatherDlg::set_cc_hmid( const QString &hmid)
 */
void CWeatherDlg::set_cc_hmid( const QString &hmid)
{
  cc_hmidLabel->setText( hmid );
}

/*!
    \fn CWeatherDlg::set_cc_icon( const QPixmap &icon )
 */
void CWeatherDlg::set_cc_icon( const QPixmap &icon )
{
  cc_iconLabel->setPixmap( icon );
}

/*!
    \fn CWeatherDlg::set_cc_t( const QString &t)
 */
void CWeatherDlg::set_cc_t( const QString &t)
{
  cc_tLabel->setText( t );
}

/*!
    \fn CWeatherDlg::set_cc_tmp( const QString &tmp)
 */
void CWeatherDlg::set_cc_tmp( const QString &tmp)
{
  cc_tmpLabel->setText( tmp );
}

/*!
    \fn CWeatherDlg::set_cc_wind_t( const QPixmap &icon )
 */
void CWeatherDlg::set_cc_wind_t( const QPixmap &icon )
{
  cc_wind_tLabel->setPixmap( icon );
}
