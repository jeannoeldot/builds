/***************************************************************************
 *   Copyright (C) 2008 by JND   *
 *   jeannoeldot@club-internet.fr   *
 *                                                                         *
 ***************************************************************************/
#ifndef CHELPBROWSER_H
#define CHELPBROWSER_H

#include <QWidget>

class QPushButton;
class QTextBrowser;

class CHelpBrowser : public QWidget
{
Q_OBJECT
public:
    CHelpBrowser(const QString &path, const QString &page, QWidget *parent = 0);

    ~CHelpBrowser();
//    static void showPage( const QString &path, const QString &page );


private slots:
    void updateWindowTitle();
private:
    QPushButton *m_backButton;
    QPushButton *m_homeButton;
    QTextBrowser *m_textBrowser;
    QPushButton *m_closeButton;
};

#endif
