/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jnd@localhost.localdomain   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#include <QApplication>
#include <QTextCodec>
#include <QTranslator>
#include <QLocale>

#include <QRegExp>
#include <QDir>

#include "afficheimage.h"



int main(int argc, char *argv[])
{
	Q_INIT_RESOURCE(application);


	QApplication app(argc, argv);

	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));

	QTranslator appTranslator;
	appTranslator.load( "progtestqt401_" + QLocale::system().name(), ":/trans");
	app.installTranslator( &appTranslator );

  QString path(QCoreApplication::instance()->applicationDirPath());

#ifdef _WIN32 
  path += "/data/";
#else
  #ifdef __APPLE__
  if (QRegExp("Contents/MacOS/?$").indexIn(path) != -1) {
    // pointing into an macosx application bundle
    path += "/../Resources/data/";
  } else { path += "/data/"; }
  #else //Unix
  if (QRegExp("progtestqt4_01/?$").indexIn(path) != -1) {
    // there is an own application directory
    path += "/data/";
  } else if (QRegExp("usr/games/bin/?$").indexIn(path) != -1) {
    // we are in /usr/games/bin (like gentoo linux does)
    path += "/../../share/games/progtestqt4_01/data/";
  } else if (QRegExp("usr/games/?$").indexIn(path) != -1) {
    // we are in /usr/games (like Debian linux does)
    path += "/../share/games/progtestqt4_01/";
  } else if (QRegExp("bin/?$").indexIn(path) != -1) {
    // we are in a bin directory. e.g. /usr/bin
    path += "/../share/progtestqt4_01/data/";
  
  } else { path += "/data/"; }
  #endif
#endif

  QString mypath = (QDir::cleanPath(path) + "/").toUtf8().constData();

  CAfficheImage * mw = new CAfficheImage();
  mw->setPathData(mypath);
	mw->show();
	return app.exec();
}

