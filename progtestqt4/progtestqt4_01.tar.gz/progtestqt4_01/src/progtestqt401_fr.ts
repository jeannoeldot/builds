<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr">
<context>
    <name>CAfficheImage</name>
    <message>
        <location filename="afficheimage.cpp" line="29"/>
        <source>ProgTest QT4</source>
        <translation>ProgTest QT4</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="80"/>
        <source>    Reformulate</source>
        <translation>    Reposer</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="96"/>
        <source>    Pick</source>
        <translation>    Piocher</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="112"/>
        <source>    Validate</source>
        <translation>    Valider</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="135"/>
        <source>PLAYER POINTS: 123   123</source>
        <translation>POINTS JOUEUR: 123   123</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="147"/>
        <source>REMAINING COUNTERS: 12</source>
        <translation>JETONS RESTANTS: 12</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="159"/>
        <source>COMPUTER POINTS: 123   123</source>
        <translation>POINTS ORDI: 123   123</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="182"/>
        <source>     Validate</source>
        <translation>     Valider</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="209"/>
        <source>&amp;New</source>
        <translation>&amp;Nouveau</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="210"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="211"/>
        <source>Create a new file</source>
        <translation>Créer un nouveau fichier</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="214"/>
        <source>&amp;Open...</source>
        <translation>&amp;Ouvrir...</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="215"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="216"/>
        <source>Open an existing file</source>
        <translation>Ouvrir un fichier existant</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="219"/>
        <source>E&amp;xit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="220"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="221"/>
        <source>Exit the application</source>
        <translation>Quitter l&apos;application</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="224"/>
        <source>Cu&amp;t</source>
        <translation>Couper</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="225"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="226"/>
        <source>Show values in pLabel0-1-2</source>
        <translation>Afficher valeur dans pLabel0-1-2</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="229"/>
        <source>&amp;Copy</source>
        <translation>Copier</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="230"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="231"/>
        <source>Copy : Disable the 4 buttons</source>
        <translation>Copier : Les 4 boutons -&gt; Disabled</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="234"/>
        <source>&amp;Paste</source>
        <translation>Coller</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="235"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="236"/>
        <source>Paste : Enable the 4 buttons</source>
        <translation>Coller : Les 4 boutons -&gt; Enabled</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="239"/>
        <source>Show Penguin</source>
        <translation>Afficher Penguin</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="241"/>
        <source>Show image Penguin.png (RVBA)</source>
        <translation>Afficher image Penguin.png (RVBA)</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="244"/>
        <source>Show FinJeu</source>
        <translation>Afficher FinJeu</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="246"/>
        <source>Show image FinJeu.png</source>
        <translation>Afficher image Penguin.png</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="249"/>
        <source>Show DessinBoule</source>
        <translation>Afficher DessinBoule</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="251"/>
        <source>Show image DessinBoule.png</source>
        <translation>Afficher image DessinBoule.png</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="254"/>
        <source>Test Sound</source>
        <translation>Test du Son</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="256"/>
        <source>Test if Sound existe and OK.</source>
        <translation>Test si Son existe et OK.</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="259"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;À propos</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="260"/>
        <source>Show the application&apos;s About box</source>
        <translation type="unfinished">Afficher la boîte À propos de</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="272"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="278"/>
        <source>&amp;Edit</source>
        <translation>&amp;Édition</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="283"/>
        <source>&amp;Test</source>
        <translation>&amp;Test</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="292"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="304"/>
        <source>Ready</source>
        <translation>Prêt</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="385"/>
        <source>About ProgTest QT4</source>
        <translation type="unfinished">À propos de ProgTest QT4</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="391"/>
        <source>&lt;h2&gt;Name of Program 1.1&lt;/h2&gt;&lt;p&gt;Copyright @ 2007 JND-Software inc.&lt;p&gt;ProgTest QT4 is a program which help me for testing many things...&lt;p&gt; &#xc3;&#xa9; &#xc3;&#xa8; &#xc3;&#xa0; &#xc3;&#xb9; &#xc3;&#xb4; &#xc3;&#xb6; &#xc3;&#xaa; &#xc3;&#xab;</source>
        <translation>&lt;h2&gt;Nom du Programme 1.1&lt;/h2&gt;&lt;p&gt;Copyright @ 2007 JND-Software inc.&lt;p&gt;ProgTest QT4 est un programme qui me permet de tester différentes choses...&lt;p&gt;é è à ç ê û î ô</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="401"/>
        <source>ProgTest QT4 - Quit</source>
        <translation>ProgTest QT4 - Quitter</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="402"/>
        <source>Quit the program ProgTest QT4?</source>
        <translation>Quitter le programme ProgTest QT4?</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="403"/>
        <source>Continue</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="404"/>
        <source>Quit</source>
        <translation>Quitter</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="430"/>
        <source>Click mouse in : X = %1 - Y = %2. posX = %3 - posY = %4. Random = %5</source>
        <translation>Clic souris en : X = %1 - Y = %2. posX = %3 - posY = %4. Hasard = %5</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="468"/>
        <source> Sound is Available !!!</source>
        <translation> Le Son est &quot; Available &quot; !!!</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="471"/>
        <source> Sound is NOT Available ^^</source>
        <translation> Le son n&apos;est PAS &quot; Available &quot; ^^</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="479"/>
        <source>ProgTest QT4 - SOUND TEST</source>
        <translation>ProgTest QT4 - TEST SON</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="480"/>
        <source>After click on OK

1) QSound::play (NO : DELETE)

2) QProcess-&gt;start(&quot;jndplaywavforqt4appli&quot;)
</source>
        <translation type="unfinished">Après avoir cliquer sur OK

1) QSound::play (NON : SUPPRIMÉ)

2) QProcess-&gt;start(&quot;jndplaywavforqt4appli&quot;)
</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="530"/>
        <source>Click on Copy</source>
        <translation>Clic sur Copier</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="532"/>
        <source>COPY TEST</source>
        <translation>TEST COPIER</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="533"/>
        <source>Click on Copy.
Disable the 4 Buttons</source>
        <translation>Clic sur Copier.
Les 4 boutons -&gt; Disabled</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="550"/>
        <source>Click on Paste</source>
        <translation>Clic sur Coller</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="552"/>
        <source>PASTE TEST</source>
        <translation>TEST COLLER</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="553"/>
        <source>Click on Paste.
Enable the 4 Buttons</source>
        <translation>Clic sur Coller.
Les 4 boutons -&gt; Enabled</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="572"/>
        <source>REMAINING COUNTERS: %1</source>
        <translation>JETONS RESTANTS: %1</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="577"/>
        <source>PLAYER POINTS: %1   %2</source>
        <translation>POINTS JOUEUR: %1   %2</translation>
    </message>
    <message>
        <location filename="afficheimage.cpp" line="582"/>
        <source>COMPUTER POINTS: %1   %2</source>
        <translation>POINTS ORDI: %1   %2</translation>
    </message>
</context>
<context>
    <name>DlgForm</name>
    <message>
        <location filename="dialogtest.ui" line="13"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogtest.ui" line="25"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogtest.ui" line="54"/>
        <source>Bleu</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <location filename="testlayout.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="testlayout.ui" line="78"/>
        <source>    Reposer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="testlayout.ui" line="118"/>
        <source>    Piocher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="testlayout.ui" line="158"/>
        <source>    Valider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="testlayout.ui" line="210"/>
        <source>POINTS JOUEUR : 123   123</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="testlayout.ui" line="231"/>
        <source>JETONS RESTANTS : 12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="testlayout.ui" line="251"/>
        <source>POINTS ORDI : 123   123</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
