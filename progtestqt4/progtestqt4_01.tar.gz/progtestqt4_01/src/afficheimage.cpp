/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jnd@localhost.localdomain   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <QtGui>
#include <QProcess>
#include <QEvent>

#include <QDomDocument>
#include <QDomElement>
#include "cweatherday.h"
#include "cweatherdlg.h"

#include "afficheimage.h"
#include "chelpbrowser.h"
#include "cdialtest.h"
#include "cverdict.h"

#include "cafficheurimage.h"

#include "SDL/sdlplayer.h"

const int MY_EVENT = QEvent::User + 10; /// 1010



const QString VERSION_PROG = "0.1";
const QString NOM_PROG = "ProgTest QT4";


CAfficheImage::CAfficheImage()
{
	setWindowTitle( NOM_PROG );
	setWindowIcon ( QIcon(":/icons/icons/Icon-appli.png") );
		
	createActions();
	createMenus();
	createStatusBar();

	QWidget *widget;
	QVBoxLayout *vboxLayout;
	QHBoxLayout *hboxLayout;
	QSpacerItem *spacerItem;
	QSpacerItem *spacerItem1;
	QSpacerItem *spacerItem2;
	QSpacerItem *spacerItem3;
	QHBoxLayout *hboxLayout1;

	widget = new QWidget(this);

	vboxLayout = new QVBoxLayout(widget);
	vboxLayout->setSpacing(6);
	vboxLayout->setMargin(0);
	vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));

//	resultSize = QSize(590, 523);
	loadImage( ":/pics/images/XPMPlateau.png", &m_imgPlateau, 590, 523 );
	m_imgMemPlateau = m_imgPlateau;
//	m_pmMemPlateau = QPixmap::fromImage(m_imgMemPlateau);

	m_afficheurImage = new CAfficheurImage( this, 590, 523 );
//	m_afficheurImage->definirPixmap( m_imgMemPlateau );
	m_afficheurImage->definirImage( m_imgMemPlateau );

	vboxLayout->addWidget(m_afficheurImage);

// 	m_imageLabel = new QLabel(this);
// 	m_imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
// 	m_imageLabel->setPixmap( m_pmMemPlateau );
// 
// 	vboxLayout->addWidget(m_imageLabel);

	hboxLayout = new QHBoxLayout();
	hboxLayout->setSpacing(6);
	hboxLayout->setMargin(0);
	hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));

	spacerItem = new QSpacerItem(21, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	hboxLayout->addItem(spacerItem);

	m_btUndo = new QPushButton(this);
	m_btUndo->setObjectName(QString::fromUtf8("BtUndo"));
	m_btUndo->setMinimumSize(QSize(130, 30));
	QFont font;
	font.setPointSize(10);
	m_btUndo->setFont(font);
	m_btUndo->setIcon(QIcon(QString::fromUtf8(":/pics/images/ICO_UNDO.png")));
	m_btUndo->setIconSize(QSize(22, 22));
	m_btUndo->setText(tr("    Reformulate")); //Reposer

	hboxLayout->addWidget(m_btUndo);

	spacerItem1 = new QSpacerItem(41, 32, QSizePolicy::Expanding, QSizePolicy::Minimum);

	hboxLayout->addItem(spacerItem1);

	m_btPiocher = new QPushButton(this);
	m_btPiocher->setObjectName(QString::fromUtf8("BtPiocher"));
	m_btPiocher->setMinimumSize(QSize(130, 30));
	QFont font1;
	font1.setPointSize(10);
	m_btPiocher->setFont(font1);
	m_btPiocher->setIcon(QIcon(QString::fromUtf8(":/pics/images/ICO_PIOCHER.png")));
	m_btPiocher->setIconSize(QSize(22, 22));
	m_btPiocher->setText(tr("    Pick"));	//Piocher

	hboxLayout->addWidget(m_btPiocher);

	spacerItem2 = new QSpacerItem(41, 32, QSizePolicy::Expanding, QSizePolicy::Minimum);

	hboxLayout->addItem(spacerItem2);

	m_btValider = new QPushButton(this);
	m_btValider->setObjectName(QString::fromUtf8("BtValider"));
	m_btValider->setMinimumSize(QSize(130, 30));
	QFont font2;
	font2.setPointSize(10);
	m_btValider->setFont(font2);
	m_btValider->setIcon(QIcon(QString::fromUtf8(":/pics/images/ICO_OK.png")));
	m_btValider->setIconSize(QSize(22, 22));
	m_btValider->setText(tr("    Validate"));	//Valider

	hboxLayout->addWidget(m_btValider);

	spacerItem3 = new QSpacerItem(21, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	hboxLayout->addItem(spacerItem3);

	vboxLayout->addLayout(hboxLayout);

	hboxLayout1 = new QHBoxLayout();
	hboxLayout1->setSpacing(6);
	hboxLayout1->setMargin(0);
	hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));

	m_pLabel0 = new QLabel(this);
	m_pLabel0->setObjectName(QString::fromUtf8("pLabel0"));
    QFont font3;
    font3.setPointSize(10);
    font3.setWeight(50);
    m_pLabel0->setFont(font3);
	m_pLabel0->setFrameShape(QFrame::WinPanel);
	m_pLabel0->setFrameShadow(QFrame::Sunken);
	m_pLabel0->setText(tr("PLAYER POINTS: 123   123"));	//POINTS JOUEUR

	hboxLayout1->addWidget(m_pLabel0);

	m_pLabel1 = new QLabel(this);
	m_pLabel1->setObjectName(QString::fromUtf8("pLabel1"));
    QFont font4;
    font4.setPointSize(10);
    font4.setWeight(50);
    m_pLabel1->setFont(font4);
	m_pLabel1->setFrameShape(QFrame::WinPanel);
	m_pLabel1->setFrameShadow(QFrame::Sunken);
	m_pLabel1->setText(tr("REMAINING COUNTERS: 12"));	//JETONS RESTANTS

	hboxLayout1->addWidget(m_pLabel1);

	m_pLabel2 = new QLabel(this);
	m_pLabel2->setObjectName(QString::fromUtf8("pLabel2"));
    QFont font5;
    font5.setPointSize(10);
    font5.setWeight(50);
    m_pLabel2->setFont(font5);
	m_pLabel2->setFrameShape(QFrame::WinPanel);
	m_pLabel2->setFrameShadow(QFrame::Sunken);
	m_pLabel2->setText(tr("COMPUTER POINTS: 123   123"));	//POINTS ORDI

	hboxLayout1->addWidget(m_pLabel2);

	vboxLayout->addLayout(hboxLayout1);

	setCentralWidget(widget);


// 	m_imageLabel =	new QLabel;
// 	setCentralWidget(m_imageLabel);
// 
// //	m_pmPlateau = QPixmap( ":/pics/images/XPMPlateau.png" ) ;
// 	resultSize = QSize(590, 523);
// 	
// 	loadImage( ":/pics/images/XPMPlateau.png", &m_imgPlateau );
// 	m_imgMemPlateau = m_imgPlateau;
// 	m_pmMemPlateau = QPixmap::fromImage(m_imgMemPlateau);
// 	m_imageLabel->setPixmap( m_pmMemPlateau );

	QPixmap pm1 = QPixmap(":/pics/images/ICO_OK.png") ;
	m_pbtConfirmer = new QPushButton( pm1, "pushButtonOK", this );
	m_pbtConfirmer->setGeometry( QRect( 220, 400, 130, 30 ) );
	m_pbtConfirmer->setText(tr("   Cacher Action"  ));
	connect( m_pbtConfirmer, SIGNAL( clicked() ), this, SLOT( testDisableAction() ) );

	QPushButton *btChoix = new QPushButton( "pBtCHOIX", this );
	btChoix->setGeometry( QRect( 420, 440, 130, 30 ) );
	btChoix->setText(tr("Meilleur Choix"  ));
	connect( btChoix, SIGNAL( clicked() ), this, SLOT( meilleurChoix() ) );

	QPushButton *btEchange = new QPushButton( "pBtECHANGE", this );
	btEchange->setGeometry( QRect( 420, 500, 130, 30 ) );
	btEchange->setText(tr("Echange Pose"  ));
	connect( btEchange, SIGNAL( clicked() ), this, SLOT( echangePose() ) );


	

	QPoint pos = QPoint(100, 100);
	QSize size = QSize(590, 584);
	setMaximumSize(size);
	resize(size);
	move(pos);

	srand ( time (0) );

	mySDLPlayer = new SDLPlayer();
  
  m_pchelpbrowser = 0;

  m_day0 = new CWeatherDay();
  m_day1 = new CWeatherDay();
  m_day2 = new CWeatherDay();
  m_day3 = new CWeatherDay();
  m_day4 = new CWeatherDay();

}


CAfficheImage::~CAfficheImage()
{
  delete mySDLPlayer;
  
  delete m_day0;
  delete m_day1;
  delete m_day2;
  delete m_day3;
  delete m_day4;
}


/*!
    \fn CAfficheImage::setPathData(const QString& path)
 */
void CAfficheImage::setPathData( const QString& path )
{
  m_pathData = path;
}


/*!
    \fn CAfficheImage::createActions()
 */
void CAfficheImage::createActions()
{
	m_newAct = new QAction(QIcon(":/filenew.xpm"), tr("&New"), this);
	m_newAct->setShortcut(tr("Ctrl+N"));
	m_newAct->setStatusTip(tr("Test envoi Custom Event"));
	connect(m_newAct, SIGNAL(triggered()), this, SLOT(newFile()));

	m_openAct = new QAction(QIcon(":/fileopen.xpm"), tr("&Open..."), this);
	m_openAct->setShortcut(tr("Ctrl+O"));
	m_openAct->setStatusTip(tr("Teste Classe CVerdict"));
	connect(m_openAct, SIGNAL(triggered()), this, SLOT(openFile()));

	m_exitAct = new QAction(tr("E&xit"), this);
	m_exitAct->setShortcut(tr("Ctrl+Q"));
	m_exitAct->setStatusTip(tr("Exit the application"));
	connect(m_exitAct, SIGNAL(triggered()), this, SLOT(closeAppli()));

	m_cutAct = new QAction(QIcon(":/editcut.xpm"), tr("Cu&t"), this);
	m_cutAct->setShortcut(tr("Ctrl+X"));
	m_cutAct->setStatusTip(tr("Show values in pLabel0-1-2"));
	connect(m_cutAct, SIGNAL(triggered()), this, SLOT(cut()));

	m_copyAct = new QAction(QIcon(":/editcopy.xpm"), tr("&Copy"), this);
	m_copyAct->setShortcut(tr("Ctrl+C"));
	m_copyAct->setStatusTip(tr("Copy : Disable the 4 buttons"));
	connect(m_copyAct, SIGNAL(triggered()), this, SLOT(copy()));

	m_pasteAct = new QAction(QIcon(":/editpaste.xpm"), tr("&Paste"), this);
	m_pasteAct->setShortcut(tr("Ctrl+V"));
	m_pasteAct->setStatusTip(tr("Paste : Enable the 4 buttons"));
	connect(m_pasteAct, SIGNAL(triggered()), this, SLOT(paste()));

	m_penguinAct = new QAction(tr("Show Penguin"), this);
//	m_penguinAct->setShortcut(tr("Ctrl+Q"));
	m_penguinAct->setStatusTip(tr("Show image Penguin.png (RVBA)"));
	connect(m_penguinAct, SIGNAL(triggered()), this, SLOT(showPenguin()));

	m_finjeuAct = new QAction(tr("Show FinJeu"), this);
//	m_finjeuAct->setShortcut(tr("Ctrl+Q"));
	m_finjeuAct->setStatusTip(tr("Show image FinJeu.png"));
	connect(m_finjeuAct, SIGNAL(triggered()), this, SLOT(showFinJeu()));

	m_dessinbouleAct = new QAction(tr("Show DessinBoule"), this);
//	m_dessinbouleAct->setShortcut(tr("Ctrl+Q"));
	m_dessinbouleAct->setStatusTip(tr("Show image DessinBoule.png"));
	connect(m_dessinbouleAct, SIGNAL(triggered()), this, SLOT(showDessinBoule()));

	m_testsoundAct = new QAction(tr("Test Sound"), this);
//	m_testsoundAct->setShortcut(tr("Ctrl+Q"));
	m_testsoundAct->setStatusTip(tr("Test if Sound existe and OK."));
	connect(m_testsoundAct, SIGNAL(triggered()), this, SLOT(testSound()));

	m_testdialAct = new QAction(tr("Show Test Dial"), this);
//	m_testdialAct->setShortcut(tr("Ctrl+Q"));
	m_testdialAct->setStatusTip(tr("Show a test dialog"));
	connect(m_testdialAct, SIGNAL(triggered()), this, SLOT(showDialTest()));

	m_testenvoitableauAct = new QAction(tr("Test envoi Tableau"), this);
//	m_testenvoitableauAct->setShortcut(tr("Ctrl+Q"));
	m_testenvoitableauAct->setStatusTip(tr("Test un envoi de tableau"));
	connect(m_testenvoitableauAct, SIGNAL(triggered()), this, SLOT(testEnvoiTableau()));

  m_testrapiditeappelfonctionAct = new QAction(tr("Test rapidité appel fonction"), this);
//  m_testrapiditeappelfonctionAct->setShortcut(tr("Ctrl+Q"));
  m_testrapiditeappelfonctionAct->setStatusTip(tr("Test rapidité appel fonction . ou ->"));
  connect(m_testrapiditeappelfonctionAct, SIGNAL(triggered()), this, SLOT(testRapiditeAppelFonction()));

	m_testrapiditeaffichageAct = new QAction(tr("Test rapidité affichage"), this);
//	m_testrapiditeaffichageAct->setShortcut(tr("Ctrl+Q"));
	m_testrapiditeaffichageAct->setStatusTip(tr("Test rapidité affichage de xxx pingouins"));
	connect(m_testrapiditeaffichageAct, SIGNAL(triggered()), this, SLOT(testRapiditeAffichage()));

	m_testtempoAct = new QAction(tr("Test temporisation"), this);
//	m_testtempoAct->setShortcut(tr("Ctrl+Q"));
	m_testtempoAct->setStatusTip(tr("Test temporisation xxxx ms"));
	connect(m_testtempoAct, SIGNAL(triggered()), this, SLOT(testTemporisation()));

	m_clignoteAct = new QAction(tr("Test clignoter"), this);
//	m_clignoteAct->setShortcut(tr("Ctrl+Q"));
	m_clignoteAct->setStatusTip(tr("Test clignoter 10 fois"));
	connect(m_clignoteAct, SIGNAL(triggered()), this, SLOT(testClignote()));

  m_testwgetAct = new QAction(tr("Test wget meteo ..."), this);
//  m_testwgetAct->setShortcut(tr("Ctrl+Q"));
  m_testwgetAct->setStatusTip(tr("Test wget url"));
  connect(m_testwgetAct, SIGNAL(triggered()), this, SLOT(testWget()));

  m_testpathAct = new QAction(tr("Test path data"), this);
//  m_testpathAct->setShortcut(tr("Ctrl+Q"));
  m_testpathAct->setStatusTip(tr("Test path data images"));
  connect(m_testpathAct, SIGNAL(triggered()), this, SLOT(testPathData()));

	m_aboutAct = new QAction(tr("&About"), this);
	m_aboutAct->setStatusTip(tr("Show the application's About box"));
	connect(m_aboutAct, SIGNAL(triggered()), this, SLOT(aboutAppli()));

	m_helpAct = new QAction(tr("&Help"), this);
	m_helpAct->setShortcut(tr("F1"));
	m_helpAct->setStatusTip(tr("Show the application's help"));
	connect(m_helpAct, SIGNAL(triggered()), this, SLOT(helpAppli()));

	
}


/*!
    \fn CAfficheImage::createMenus()
 */
void CAfficheImage::createMenus()
{
	m_fileMenu = menuBar()->addMenu(tr("&File"));
	m_fileMenu->addAction(m_newAct);
	m_fileMenu->addAction(m_openAct);
	m_fileMenu->addSeparator();
	m_fileMenu->addAction(m_exitAct);

	m_editMenu = menuBar()->addMenu(tr("&Edit"));
	m_editMenu->addAction(m_cutAct);
	m_editMenu->addAction(m_copyAct);
	m_editMenu->addAction(m_pasteAct);

	m_testMenu = menuBar()->addMenu(tr("&Test"));
	m_testMenu->addAction(m_penguinAct);
	m_testMenu->addAction(m_finjeuAct);
	m_testMenu->addAction(m_dessinbouleAct);
	m_testMenu->addSeparator();
	m_testMenu->addAction(m_testsoundAct);
	m_testMenu->addAction(m_testdialAct);
	m_testMenu->addAction(m_testenvoitableauAct);
	m_testMenu->addSeparator();
  m_testMenu->addAction(m_testrapiditeappelfonctionAct);
	m_testMenu->addAction(m_testrapiditeaffichageAct);
	m_testMenu->addAction(m_testtempoAct);
	m_testMenu->addAction(m_clignoteAct);
  m_testMenu->addSeparator();
  m_testMenu->addAction(m_testwgetAct);
  m_testMenu->addAction(m_testpathAct);
	
	menuBar()->addSeparator();

	m_helpMenu = menuBar()->addMenu(tr("&Help"));
	m_helpMenu->addAction(m_helpAct);
	m_helpMenu->addSeparator();
	m_helpMenu->addAction(m_aboutAct);

	m_heightMenuBar = menuBar()->height();
}

void CAfficheImage::createStatusBar()
{
    QFont font;
    font.setBold( TRUE );
	statusBar()->setFont(font);

	statusBar()->showMessage(tr("Ready"));
}

/*!
    \fn CAfficheImage::showPenguin()
 */
void CAfficheImage::showPenguin()
{
//	resultSize = QSize(128, 128);
	loadImage( ":/pics/images/penguin.png", &m_imgPenguin, 128, 128 );
//	m_imgCopie = m_imgMemPlateau;
	QPainter painter(&m_imgMemPlateau);
	painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
	painter.drawImage(105, 190, m_imgPenguin);
	painter.end();
//	m_imgMemPlateau = m_imgCopie;
	
// 	m_pmMemPlateau = QPixmap::fromImage(m_imgMemPlateau);
// 	m_imageLabel->setPixmap( m_pmMemPlateau );

// 	m_afficheurImage->definirPixmap( m_imgMemPlateau );
// 	m_afficheurImage->update();

	m_afficheurImage->afficheImage( m_imgMemPlateau );
}


/*!
    \fn CAfficheImage::
 */
void CAfficheImage::showFinJeu()
{
//	resultSize = QSize(356, 357);
	loadImage( ":/pics/images/FinJeu.png", &m_imgFinJeu, 356, 357 );
//	m_imgCopie = m_imgMemPlateau;
	QPainter painter(&m_imgMemPlateau);
	painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
	painter.drawImage(170, 130, m_imgFinJeu);
	painter.end();
//	m_imgMemPlateau = m_imgCopie;
	
// 	m_pmMemPlateau = QPixmap::fromImage(m_imgMemPlateau);
// 	m_imageLabel->setPixmap( m_pmMemPlateau );

// 	m_afficheurImage->definirPixmap( m_imgMemPlateau );
// 	m_afficheurImage->update();

	m_afficheurImage->afficheImage( m_imgMemPlateau );
}

/*!
    \fn CAfficheImage::showDessinBoule()
 */
void CAfficheImage::showDessinBoule()
{
//	resultSize = QSize(120, 30);
	loadImage( ":/pics/images/DessinBoule.png", &m_imgDessinBoule, 120, 30 );
//	m_imgCopie = m_imgMemPlateau;
	QPainter painter(&m_imgMemPlateau);
	painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
	painter.drawImage(140, 400, m_imgDessinBoule);
	painter.end();
//	m_imgMemPlateau = m_imgCopie;
	
// 	m_pmMemPlateau = QPixmap::fromImage(m_imgMemPlateau);
// 	m_imageLabel->setPixmap( m_pmMemPlateau );

// 	m_afficheurImage->definirPixmap( m_imgMemPlateau );
// 	m_afficheurImage->update();

	m_afficheurImage->afficheImage( m_imgMemPlateau );
}

/*!
    \fn CAfficheImage::afficheUneBoule( const int x, const int y, const int couleur )
 */
void CAfficheImage::afficheUneBoule( const int x, const int y, const int couleur )
{
//	resultSize = QSize(120, 30);
	loadImage( ":/pics/images/DessinBoule.png", &m_imgDessinBoule, 120, 30 );
//	m_imgCopie = m_imgMemPlateau;
	QPainter painter(&m_imgMemPlateau);
	painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
	painter.drawImage( x-11, y, m_imgDessinBoule, couleur*30, 0, 22, 22 );
	painter.end();
//	m_imgMemPlateau = m_imgCopie;
	
// 	m_pmMemPlateau = QPixmap::fromImage(m_imgMemPlateau);
// 	m_imageLabel->setPixmap( m_pmMemPlateau );

// 	m_afficheurImage->definirPixmap( m_imgMemPlateau );
// 	m_afficheurImage->update();

	m_afficheurImage->afficheImage( m_imgMemPlateau );

}

/*!
    \fn CAfficheImage::loadImage(const QString &fileName, QImage *image, const int width, const int height)
 */
void CAfficheImage::loadImage( const QString &fileName, QImage *image, const int width, const int height )
{
	image->load(fileName);

//	QImage fixedImage(resultSize, QImage::Format_ARGB32_Premultiplied);
	QImage fixedImage(width, height, QImage::Format_ARGB32_Premultiplied);
	QPainter painter(&fixedImage);
	painter.setCompositionMode(QPainter::CompositionMode_Source);
	painter.fillRect(fixedImage.rect(), Qt::transparent);
	painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
	painter.drawImage( 0, 0, *image );
	painter.end();
	
	*image = fixedImage;
}



/*!
    \fn CAfficheImage::newFile()
 */
void CAfficheImage::newFile()
{
//    QEvent event( (QEvent::Type)(1001) );

	int hasard = genererHasard_0_5();
	hasard = hasard * 10;
	

	QEvent event( (QEvent::Type)(MY_EVENT + hasard) );
	QApplication::sendEvent( this, &event );
}


/*!
    \fn CAfficheImage::openFile()
 */
void CAfficheImage::openFile()
{
	CVerdict effet( FALSE );
	effet = lectureCVerdict();
	bool f = effet.a_gagne();

	QString msg;
	if( TRUE == f )	msg = tr("TRUE : OK");
	if( FALSE == f )	msg = tr("FALSE : PAS BON");
	QMessageBox::information( this, NOM_PROG + tr(" - CVERDICT TEST"), msg );
}


/*!
    \fn CAfficheImage::lectureCVerdict()
 */
CVerdict CAfficheImage::lectureCVerdict()
{
	CVerdict resultat( FALSE );
	resultat.setA_Gagne( TRUE );
	return resultat;
}

/*!
    \fn CAfficheImage::aboutAppli()
 */
void CAfficheImage::aboutAppli()
{
	QMessageBox::about ( this, tr("About ") + NOM_PROG,
						tr("<h2>Name of Program 1.1</h2>"
						"<p>Copyright @ 2007 JND-Software inc."
						"<p>ProgTest QT4 is a program"
						" which help me for testing many"
						" things..."
						  "<p> é è à ù ô ö ê ë") );

}


/*!
    \fn CAfficheImage::closeAppli()
 */
void CAfficheImage::closeAppli()
{
	int reponse = QMessageBox::question ( this, NOM_PROG + tr(" - Quit"),
										  tr("Quit the program ProgTest QT4?"),
											tr("Continue"),	/// index 0
											tr("Quit"),	/// index 1
											QString::null,		/// index 2
				  1, 0 );
		
	switch (reponse)
	{
		case 0 : break;			/// Continuer
		case 1 : qApp->quit();	break;	/// Arrêter
	}
}


/*!
    \fn CAfficheImage::mousePressEvent( QMouseEvent *e )
 */
void CAfficheImage::mousePressEvent( QMouseEvent *e )
{
	QString message, moremsg;

	int posx = e->x();
	int posy = e->y();
	posy-= m_heightMenuBar;	/// hauteur barre menu
	posy -= 7;	/// hauteur cadre dessiné

	int hasard = genererHasard_0_3();
	
	message = QString( tr("Click mouse in : X = %1 - Y = %2. posX = %3 - posY = %4. Random = %5").arg(e->x()).arg(e->y()).arg(posx).arg(posy).arg(hasard));
	statusBar()->showMessage(message);
	
	afficheUneBoule( posx, posy, hasard );

}



/*!
    \fn CAfficheImage::testSound()
 */
void CAfficheImage::testSound()
{
/*
	bool SonExiste;
	SonExiste = QSound::isAvailable();
	switch (SonExiste)
	{
		case TRUE : 	QMessageBox::information( 0, "TEST isAvailable",
						QString(tr(" Sound is Available !!!")) );
			break;
		case FALSE : 	QMessageBox::information( 0, "TEST isAvailable",
						QString(tr(" Sound is NOT Available ^^")) );
			break;
	}
*/
	
	QMessageBox::information( this, NOM_PROG + tr(" - SOUND TEST"),
							  QString(tr("After click on OK\n\n1) QSound::play (NO : DELETE)\n\n2) QProcess->start(\"jndplaywavforqt4appli\") (NON)\n\n3) SDL_mixer\n" )) );


/*	QDir d = QDir::root();		/// "/"
	if ( d.cd( "usr/share/sounds") )
	{
		QFile f( d.filePath( "JNDprogtestqt4_err.wav" ) );
		if ( f.exists() )
		{
			m_fichiersonerreur = QString( "/usr/share/sounds/JNDprogtestqt4_err.wav" );
		}
		else
		{
			m_fichiersonerreur = QString("/home/jnd/00-dev/00-cpp/02-qt4/progtestqt401/sounds/JNDprogtestqt4_err.wav");
		}
	}
*/

/// TEST N°1
/// PAS D'ERREUR; MAIS PAS DE SON
///		QSound erreur(m_fichiersonerreur);
///		erreur.play();
///********************************************


/// TEST N°2 = OK 
// 	QString program = "jndplaywavforqt4appli";
// 	QStringList arguments;
// 	arguments << m_fichiersonerreur;
// 	QProcess *myProcess = new QProcess(this);
// 	myProcess->start(program, arguments);
// 	myProcess->waitForFinished();

/// TEST N°3 = OK 
/// SDL_mixer
///**********

	mySDLPlayer->playSound("JNDprogtestqt4_err");


/// TEST N°4 = OK 
/// SDL_mixer
///**********

	QMessageBox::information( this, NOM_PROG + tr(" - SDL_MIXER TEST"),
							  QString(tr("After click on OK\n\n1) SDL_mixer ID = 0\n" )) );

	mySDLPlayer->playSound("door", 0);
	
	QMessageBox::information( this, NOM_PROG + tr(" - SDL_MIXER TEST"),
							  QString(tr("After click on OK\n\n1) SDL_mixer ID = 1\n" )) );
	mySDLPlayer->playSound("door", 1);
	
	QMessageBox::information( this, NOM_PROG + tr(" - SDL_MIXER TEST"),
							  QString(tr("After click on OK\n\n1) SDL_mixer ID = 2\n" )) );
	mySDLPlayer->playSound("door", 2);
	
	QMessageBox::information( this, NOM_PROG + tr(" - SDL_MIXER TEST"),
							  QString(tr("After click on OK\n\n1) SDL_mixer ID = 3\n" )) );
	mySDLPlayer->playSound("door", 3);


}




/*!
    \fn CAfficheImage::copy()
 */
void CAfficheImage::copy()
{
	if( m_pbtConfirmer->isEnabled() == TRUE )
	{
	QString message = tr("Click on Copy");
	statusBar()->showMessage(message);
	QMessageBox::information( this, tr("COPY TEST"),
							  QString(tr("Click on Copy.\nDisable the 4 Buttons" )) );
//	m_pbtConfirmer->hide();
	m_pbtConfirmer->setEnabled ( FALSE );
	m_btUndo->setEnabled ( FALSE );
	m_btPiocher->setEnabled ( FALSE );
	m_btValider->setEnabled ( FALSE );
	}
}


/*!
    \fn CAfficheImage::paste()
 */
void CAfficheImage::paste()
{
	if( m_pbtConfirmer->isEnabled() == FALSE )
	{
	QString message = tr("Click on Paste");
	statusBar()->showMessage(message);
	QMessageBox::information( this, tr("PASTE TEST"),
							  QString(tr("Click on Paste.\nEnable the 4 Buttons" )) );
//	m_pbtConfirmer->show();
	m_pbtConfirmer->setEnabled ( TRUE );
	m_btUndo->setEnabled ( TRUE );
	m_btPiocher->setEnabled ( TRUE );
	m_btValider->setEnabled ( TRUE );
	}
}


/*!
    \fn CAfficheImage::cut()
 */
void CAfficheImage::cut()
{
	int hasard1, hasard2;
	QString message;
	hasard1 = GenereHasard_0_999();
	hasard2 = GenereHasard_0_999();
	message = QString(tr("REMAINING COUNTERS: %1").arg(hasard1));
	m_pLabel1->setText( message );

	hasard1 = GenereHasard_0_999();
	hasard2 = GenereHasard_0_999();
	message = QString(tr("PLAYER POINTS: %1   %2").arg(hasard1).arg(hasard2)); /// POSE - PARTIE
	m_pLabel0->setText( message );

	hasard1 = GenereHasard_0_999();
	hasard2 = GenereHasard_0_999();
	message = QString(tr("COMPUTER POINTS: %1   %2").arg(hasard1).arg(hasard2)); /// POSE - PARTIE
	m_pLabel2->setText(message);
}

int CAfficheImage::GenereHasard_0_999()
{
	quint16 hasard = 10 + (int) (10000.0*rand()/(RAND_MAX+1.0));	/// de 10 a 10000
	hasard = hasard / 10;					/// de 1 à 1000
	if ( hasard > 0 ) hasard -= 1;				/// de 0 à 999
	if ( hasard >= 1000 ) hasard = 999;
	return	hasard;
}

/*!
    \fn CAfficheImage::genererHasard_0_3()
 */
int CAfficheImage::genererHasard_0_3()
{
	quint16 hasard = 10 + (int) (40.0*rand()/(RAND_MAX+1.0));	/// de 10 a 40
	hasard = hasard / 10;					/// de 1 à 4
	if ( hasard > 0 ) hasard -= 1;			/// de 0 à 3
	if ( hasard >= 4 ) hasard = 3;
	return	hasard;
}


/*!
    \fn CAfficheImage::genererHasard_0_5()
 */
int CAfficheImage::genererHasard_0_5()
{
  quint16 hasard = 10 + (int) (60.0*rand()/(RAND_MAX+1.0)); /// de 10 a 60
  hasard = hasard / 10;         /// de 1 à 6
  if ( hasard > 0 ) hasard -= 1;      /// de 0 à 5
  if ( hasard >= 6 ) hasard = 5;
  return  hasard;
}


/*!
    \fn CAfficheImage::genererHasard_0_48()
 */
int CAfficheImage::genererHasard_0_48()
{
  quint16 hasard = 10 + (int) (490.0*rand()/(RAND_MAX+1.0)); /// de 10 a 490
  hasard = hasard / 10;         /// de 1 à 49
  if ( hasard > 0 ) hasard -= 1;      /// de 0 à 48
  if ( hasard >= 49 ) hasard = 48;
  return  hasard;
}


/*!
    \fn CAfficheImage::helpAppli()
 */
void CAfficheImage::helpAppli()
{
/*
	QString path;

	QDir d = QDir::root();		/// "/"
	if ( d.cd( "usr/share/progtestqt401/docs") )
	{
		QFile f( d.filePath( "JNDprogtestqt4.html" ) );
		if ( f.exists() )
		{
			path = QString( "/usr/share/progtestqt401/docs" );
		}
		else
		{
			path = QString("/home/jnd/00-dev/00-cpp/02-qt4/progtestqt401/docs");
		}
	}
	else
	{
			path = QString("/home/jnd/00-dev/00-cpp/02-qt4/progtestqt401/docs");
	}

	CHelpBrowser::showPage( path, "JNDprogtestqt4.html" );
*/ 

  QString path = m_pathData + "docs";
  
  if( !m_pchelpbrowser )
  {
    m_pchelpbrowser = new CHelpBrowser( path, "JNDprogtestqt4.html" );
  }
  
  m_pchelpbrowser->show();
  m_pchelpbrowser->activateWindow();

}


/*!
    \fn CAfficheImage::showDialTest()
 */
void CAfficheImage::showDialTest()
{
  CDialTest dial( this );
  dial.exec();
}


/*!
    \fn CAfficheImage::testEnvoiParametre()
 */
void CAfficheImage::testEnvoiTableau()
{
	const int fibonacci[10] = {0,1,2,3,4,5,6,7,8,9};
	testRecoitTableau( fibonacci, 10 );
}


/*!
    \fn CAfficheImage::testRecoitTableau( const int *tableau, int size )
 */
void CAfficheImage::testRecoitTableau( const int *tableau, int size )
{
	int table[10];
	for( int i = 0; i < size; ++i )
	{
		table[i] = tableau[i] + 10;
	}

	QMessageBox::information( this, tr("TEST ENVOI"),
							  QString(tr("Avant:\n0 1 2 3 4 5 6 7 8 9\n\nAprès:\n%1 %2 %3 %4 %5 %6 %7 %8 %9 %10" ))
							  .arg(table[0])
							  .arg(table[1])
							  .arg(table[2])
							  .arg(table[3])
							  .arg(table[4])
							  .arg(table[5])
							  .arg(table[6])
							  .arg(table[7])
							  .arg(table[8])
							  .arg(table[9])
							   );

}


/*!
    \fn CAfficheImage::testDisableAction()
 */
void CAfficheImage::testDisableAction()
{
	if( m_finjeuAct->isEnabled() == TRUE )
	{
		m_finjeuAct->setEnabled( FALSE );
		m_pbtConfirmer->setText(tr("   Afficher Action"  ));
	}
	else
	{
		m_finjeuAct->setEnabled( TRUE );
		m_pbtConfirmer->setText(tr("   Cacher Action"  ));
	}
}


/*!
    \fn CAfficheImage::meilleurChoix()
 */
void CAfficheImage::meilleurChoix()
{
	QMessageBox::information( this, tr("CHOIX"),
							  QString(tr("Vous avez cliqué sur:\n\nMeilleur Choix" )) );
}


/*!
    \fn CAfficheImage::echangePose()
 */
void CAfficheImage::echangePose()
{
	QMessageBox::information( this, tr("ECHANGE"),
							  QString(tr("Vous avez cliqué sur:\n\nEchanger Pose" )) );
}


/*!
    \fn CAfficheImage::customEvent(QEvent * event)
 */
void CAfficheImage::customEvent(QEvent * event)
{
	QString msg;
	switch ( event->type() )
	{
		case 1010 :
		msg = tr("Event 1010 : EST PIOCHE");
		break;
		case 1020 :
		msg = tr("Event 1020 : EST TIRE");
		break;
		case 1030 :
		msg = tr("Event 1030 : NORD PIOCHE");
		break;
		case 1040 :
		msg = tr("Event 1040 : NORD TIRE");
		break;
		case 1050 :
		msg = tr("Event 1050 : OUEST PIOCHE");
		break;
		case 1060 :
		msg = tr("Event 1060 : OUEST TIRE");
		break;
		default :
		msg = "???";
		break;
	}
		
	QMessageBox::information( this, tr("TEST"), msg );

}


/*!
    \fn CAfficheImage::testRapiditeAffichage()
 */
void CAfficheImage::testRapiditeAffichage()
{
// QTime t;
//  t.start();
//  some_lengthy_task();
//  qDebug("Time elapsed: %d ms", t.elapsed());

	QString timeavant;
	QString timeapres;
	QString	duree;
	QTime t;
	t.start();
	QTime t0;
	t0.start();
	timeavant = t0.toString ( "hh:mm:ss.zzz" );

	for( int i = 0; i < 1000; i++ )
	{
		qApp->processEvents();
		showPenguin();
	}

	QTime t1;
	t1.start();
	timeapres = t1.toString ( "hh:mm:ss.zzz" );

	long n = t.elapsed();
	duree.setNum( n );
	
	QMessageBox::information( this, tr("TEST RAPIDITE"),
							  QString(tr("Avant: %1\n\nAprès: %2\n\nDurée = %3 ms\n" ))
							  .arg(timeavant)
							  .arg(timeapres)
								.arg(duree)
							   );

}


/*!
    \fn CAfficheImage::testTemporisation()
 */
void CAfficheImage::testTemporisation()
{
	QString timeavant;
	QString timeapres;

	long n;
	long temporisation = 2000;		/// en milliseconde (1000 = 1 seconde)
	QTime t;
	QTime t0;
	QTime t1;

	t0.start();
	timeavant = t0.toString ( "hh:mm:ss.zzz" );
	t.start();

	showPenguin();

	while ( TRUE )
	{
		n = t.elapsed();
		if ( n > temporisation )	break;
		qApp->processEvents();	
	}
	t1.start();
	timeapres = t1.toString ( "hh:mm:ss.zzz" );

	QMessageBox::information( this, tr("TEST TEMPORISATION"),
							  QString(tr("Avant: %1\n\nAprès: %2\n" ))
							  .arg(timeavant)
							  .arg(timeapres)
							   );

}


/*!
    \fn CAfficheImage::testClignote()
 */
void CAfficheImage::testClignote()
{
/// Image propre et sans boule dans imgPlateauSansBoule
	showFinJeu();
	QImage imgPlateauSansBoule;
	imgPlateauSansBoule = m_imgMemPlateau;

/// Image propre et avec 1 boule dans imgPlateauAvecBoule
	afficheUneBoule( 333, 182, 0 );		/// bleu = 0, Orange = 1
	QImage imgPlateauAvecBoule;
	imgPlateauAvecBoule = m_imgMemPlateau;

	long n;
	QTime t;

	int nbfois;
	nbfois = 10;	/// 10 x 150 = 1500 ms

	for( int i = 0; i < nbfois; i++ )
	{
		m_afficheurImage->afficheImage( imgPlateauAvecBoule );
		t.start();

		while ( TRUE )
		{
			n = t.elapsed();
			if ( n > 75 )	break;
			qApp->processEvents();	
		}

		m_afficheurImage->afficheImage( imgPlateauSansBoule );
		t.start();

		while ( TRUE )
		{
			n = t.elapsed();
			if ( n > 75 )	break;
			qApp->processEvents();	
		}
	}

	m_afficheurImage->afficheImage( m_imgMemPlateau );

}


/*!
    \fn CAfficheImage::testRapiditeAppelFonction()
 */
void CAfficheImage::testRapiditeAppelFonction()
{
// QTime t;
//  t.start();
//  some_lengthy_task();
//  qDebug("Time elapsed: %d ms", t.elapsed());

  QString timeavant;
  QString timeapres;
  QString duree;
  
  QTime t0;
  t0.start();
  for( int i = 0; i < 20000; i++ )
  {
    qApp->processEvents();
    CVerdict cv0;
    cv0.setA_Gagne( true );
  }
  qDebug("Time elapsed cv.fn(): %d ms", t0.elapsed());

  QTime t1;
  t1.start();
  CVerdict * p_cv1 = new CVerdict( false );
  for( int i = 0; i < 20000; i++ )
  {
    qApp->processEvents();
    p_cv1->setA_Gagne( true );
  }
  qDebug("Time elapsed cv->fn(): %d ms", t1.elapsed());

  QTime t3;
  t3.start();
  for( int i = 0; i < 20000; i++ )
  {
    qApp->processEvents();
    CVerdict cv3;
    cv3.m_a_gagne = true;
  }
  qDebug("Time elapsed cv.var: %d ms", t3.elapsed());

  QTime t2;
  t2.start();
  CVerdict * p_cv2 = new CVerdict( false );
  for( int i = 0; i < 20000; i++ )
  {
    qApp->processEvents();
    p_cv2->m_a_gagne = true;
  }
  qDebug("Time elapsed cv->var: %d ms", t2.elapsed());




//   QTime t0;
//   t0.start();
//   timeavant = t0.toString ( "hh:mm:ss.zzz" );

//   QTime t1;
//   t1.start();
//   timeapres = t1.toString ( "hh:mm:ss.zzz" );

//   long n = t.elapsed();
//   duree.setNum( n );
//   
//   QMessageBox::information( this, tr("TEST RAPIDITE"),
//                 QString(tr("Avant: %1\n\nAprès: %2\n\nDurée = %3\n" ))
//                 .arg(timeavant)
//                 .arg(timeapres)
//                 .arg(duree)
//                  );

}




/*!
    \fn CAfficheImage::testPathData()
 */
void CAfficheImage::testPathData()
{
  QImage imgPNG;
  QString codePNG;
  int hasard = genererHasard_0_48();
  codePNG.setNum( hasard );
  QString pathimg = m_pathData + "themes/Liquid/large_icons/" + codePNG + ".png";
  imgPNG = QImage( pathimg );

  QPoint destination(100, 400);
  QPainter painter(&m_imgMemPlateau);
  painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
  painter.drawImage( destination, imgPNG );
  painter.end();
  m_afficheurImage->afficheImage( m_imgMemPlateau );

}


/*!
    \fn CAfficheImage::testWget()
 */
void CAfficheImage::testWget()
{
    ///retrive the weather file
//wget -O /home/jnd/Téléchargement/weather/liquidweather.xml //http://xoap.weather.com/weather/local/FRXX0077?cc=*&dayf=5&par=1003666583&key=4128909340a9b2fc

//    QString command = "wget -O " + QDir::homePath() + "/.weather.xml http://weather.yahooapis.com/forecastrss?p=" + zip;

//    if(tempType == "C")
//    {
//       command.append("&u=c");
//    }
    
//wget -O /home/jnd/Téléchargement/weather/ClearWeatherScreenlet.xml //http://xoap.weather.com/weather/local/FRXX0077?cc=*&dayf=10&prod=xoap&par=1003666583&key=4128909340a9b2fc&unit=m&link=xoap
    
    QString path = "/home/jnd/99-temp";
    QString file = "myweather.xml";
    QString debut_url = "http://xoap.weather.com/weather/local/";
    QString zip = "FRXX0077";
//    QString fin_url = "?cc=*&dayf=5&par=1003666583&key=4128909340a9b2fc";
    QString unite = "m";
    QString fin_url = "?cc=*&dayf=10&prod=xoap&par=1003666583&key=4128909340a9b2fc&unit=";
    
    QString command = "wget -O " + path + "/" + file + " " + debut_url + zip + fin_url + unite + "&link=xoap";
    
    QProcess* process = new QProcess(this);
    
    process->start(command);
    process->waitForFinished();
    delete process;
    
    ///get the invidual elements from the XML file
    QDomDocument doc("weather");
    QFile filename( path + "/" + file );

    ///read the data into the XML parser and close the file
    doc.setContent(&filename);
    filename.close();

    QDomElement root = doc.documentElement();

    
    QDomNode node = root.firstChild();
    while ( !node.isNull() )
    {
      if ( node.toElement().tagName() == "head" )
      {
        weatherParseHead( node.toElement() );
      }
      else if ( node.toElement().tagName() == "loc" )
      {
        weatherParseLoc( node.toElement() );
      }
      else if ( node.toElement().tagName() == "cc" )
      {
        weatherParseCc( node.toElement() );
      }
      else if ( node.toElement().tagName() == "dayf" )
      {
        weatherParseDayf( node.toElement() );
      }
      node = node.nextSibling();
    }

    weatherSetDialogMeteo();

}




/*!
    \fn CAfficheImage::weatherParseHead( const QDomElement &element )
 */
void CAfficheImage::weatherParseHead( const QDomElement &element )
{
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "ut" )
    {
      QDomNode childNode = node.firstChild();
      m_head_ut = childNode.toText().data();
      qDebug("head ut : %s", qPrintable( m_head_ut ) );               
    }
    else if( node.toElement().tagName() == "us" )
    {
      QDomNode childNode = node.firstChild();
      m_head_us = childNode.toText().data();
      qDebug("head us : %s", qPrintable( m_head_us ) );               
    }
    else if( node.toElement().tagName() == "up" )
    {
      QDomNode childNode = node.firstChild();
      m_head_up = childNode.toText().data();
      qDebug("head up : %s", qPrintable( m_head_up ) );               
    }
    node = node.nextSibling();
  }
}


/*!
    \fn CAfficheImage::weatherParseLoc( const QDomElement &element )
 */
void CAfficheImage::weatherParseLoc( const QDomElement &element )
{
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "dnam" )
    {
      QDomNode childNode = node.firstChild();
      m_loc_dnam = childNode.toText().data();
      qDebug("loc dnam : %s", qPrintable( m_loc_dnam ) );               
    }
    else if( node.toElement().tagName() == "sunr" )
    {
      QDomNode childNode = node.firstChild();
      m_loc_sunr = childNode.toText().data();
      weatherConvertSunr( m_loc_sunr );
      qDebug("loc sunr : %s", qPrintable( m_loc_sunr ) );               
    }
    else if( node.toElement().tagName() == "suns" )
    {
      QDomNode childNode = node.firstChild();
      m_loc_suns = childNode.toText().data();
      weatherConvertSuns( m_loc_suns );
      qDebug("loc suns : %s", qPrintable( m_loc_suns ) );               
    }
    node = node.nextSibling();
  }
}


/*!
    \fn CAfficheImage::weatherParseCc( const QDomElement &element )
 */
void CAfficheImage::weatherParseCc( const QDomElement &element )
{
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "tmp" )
    {
      QDomNode childNode = node.firstChild();
      m_cc_tmp = childNode.toText().data();
      qDebug("cc tmp : %s", qPrintable( m_cc_tmp ) );               
    }
    else if( node.toElement().tagName() == "t" )
    {
      QDomNode childNode = node.firstChild();
      m_cc_t = childNode.toText().data();
      qDebug("cc t : %s", qPrintable( m_cc_t ) );               
    }
    else if( node.toElement().tagName() == "icon" )
    {
      QDomNode childNode = node.firstChild();
      m_cc_icon = childNode.toText().data();
      qDebug("cc icon : %s", qPrintable( m_cc_icon ) );               
    }
    else if( node.toElement().tagName() == "hmid" )
    {
      QDomNode childNode = node.firstChild();
      m_cc_hmid = childNode.toText().data();
      qDebug("cc hmid : %s", qPrintable( m_cc_hmid ) );               
    }
    else if( node.toElement().tagName() == "bar" )
    {
      weatherParseBar( node.toElement(), m_cc_bar_r, m_cc_bar_d );
      qDebug(" cc bar r : %s", qPrintable( m_cc_bar_r ) );               
      qDebug(" cc bar d : %s", qPrintable( m_cc_bar_d ) );               
    }
    else if( node.toElement().tagName() == "wind" )
    {
      weatherParseWind( node.toElement(), m_cc_wind_s, m_cc_wind_t );
      qDebug(" cc wind s : %s", qPrintable( m_cc_wind_s ) );               
      qDebug(" cc wind t : %s", qPrintable( m_cc_wind_t ) );               
    }
    node = node.nextSibling();
  }
}


/*!
    \fn CAfficheImage::weatherParseDayf( const QDomElement &element )
 */
void CAfficheImage::weatherParseDayf( const QDomElement &element )
{

  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "day" )
    {
      CWeatherDay day;
      weatherParseDay( node.toElement(), day );
      
      if( day.d == "0" )
      {
        weatherSetDayNum( m_day0, day );
        weatherAfficheDayNum( m_day0 );
      }
      else if( day.d == "1" )
      {
        weatherSetDayNum( m_day1, day );
        weatherAfficheDayNum( m_day1 );
      }
      else if( day.d == "2" )
      {
        weatherSetDayNum( m_day2, day );
        weatherAfficheDayNum( m_day2 );
      }
      else if( day.d == "3" )
      {
        weatherSetDayNum( m_day3, day );
        weatherAfficheDayNum( m_day3 );
      }
      else if( day.d == "4" )
      {
        weatherSetDayNum( m_day4, day );
        weatherAfficheDayNum( m_day4 );
      }
    }
    node = node.nextSibling();
  }
}


/*!
    \fn CAfficheImage::weatherAfficheDayNum( const CWeatherDay *daynum )
 */
void CAfficheImage::weatherAfficheDayNum( const CWeatherDay *daynum )
{
        qDebug("m_day d : %s", qPrintable( daynum->d ) );               
        qDebug("m_day t : %s", qPrintable( daynum->t ) );               
        qDebug("  low : %s", qPrintable( daynum->low ) );               
        qDebug("  hi : %s", qPrintable( daynum->hi ) );               
  
        qDebug("  part d icon : %s", qPrintable( daynum->d_icon ) );               
        qDebug("  part d t : %s", qPrintable( daynum->d_t ) );               
        qDebug("  part d wind s : %s", qPrintable( daynum->d_wind_s ) );               
        qDebug("  part d wind t : %s", qPrintable( daynum->d_wind_t ) );               
        qDebug("  part d ppcp : %s", qPrintable( daynum->d_ppcp ) );
        qDebug("  part d hmid : %s", qPrintable( daynum->d_hmid ) );
                      
        qDebug("  part n icon : %s", qPrintable( daynum->n_icon ) );               
        qDebug("  part n t : %s", qPrintable( daynum->n_t ) );               
        qDebug("  part n wind s : %s", qPrintable( daynum->n_wind_s ) );               
        qDebug("  part n wind t : %s", qPrintable( daynum->n_wind_t ) );               
        qDebug("  part n ppcp : %s", qPrintable( daynum->n_ppcp ) );               
        qDebug("  part n hmid : %s", qPrintable( daynum->n_hmid ) );
}

/*!
    \fn CAfficheImage::weatherSetDayNum( CWeatherDay *daynum, const CWeatherDay &day )
 */
void CAfficheImage::weatherSetDayNum( CWeatherDay *daynum, const CWeatherDay &day )
{
        daynum->d = day.d;
//        daynum->t = day.t;
        daynum->setNameDay( day.t );
        daynum->low = day.low;
        daynum->hi = day.hi;
        
        daynum->d_icon = day.d_icon;
        daynum->d_t = day.d_t;
        daynum->d_wind_s = day.d_wind_s;
        daynum->d_wind_t = day.d_wind_t;
        daynum->d_ppcp = day.d_ppcp;
        daynum->d_hmid = day.d_hmid;
        
        daynum->n_icon = day.n_icon;
        daynum->n_t = day.n_t;
        daynum->n_wind_s = day.n_wind_s;
        daynum->n_wind_t = day.n_wind_t;
        daynum->n_ppcp = day.n_ppcp;
        daynum->n_hmid = day.n_hmid;
}

/*!
    \fn CAfficheImage::weatherParseDay( const QDomElement &element, CWeatherDay &day )
 */
void CAfficheImage::weatherParseDay( const QDomElement &element, CWeatherDay &day )
{
  day.d = element.attribute("d");
  day.t = element.attribute("t");
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "hi" )
    {
      QDomNode childNode = node.firstChild();
      day.hi = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "low" )
    {
      QDomNode childNode = node.firstChild();
      day.low = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "part" )
    {
      QDomElement part = node.toElement();
      if( part.attribute("p") == "d" )
      {
        weatherParsePart_d( node.toElement(), day );
      }
      else if( part.attribute("p") == "n" )
      {
        weatherParsePart_n( node.toElement(), day );
      }
    }
    node = node.nextSibling();
  }

}


/*!
    \fn CAfficheImage::weatherParsePart_d( const QDomElement &element, CWeatherDay &day )
 */
void CAfficheImage::weatherParsePart_d( const QDomElement &element, CWeatherDay &day )
{
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "icon" )
    {
      QDomNode childNode = node.firstChild();
      day.d_icon = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "t" )
    {
      QDomNode childNode = node.firstChild();
      day.d_t = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "ppcp" )
    {
      QDomNode childNode = node.firstChild();
      day.d_ppcp = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "hmid" )
    {
      QDomNode childNode = node.firstChild();
      day.d_hmid = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "wind" )
    {
      weatherParseWind( node.toElement(), day.d_wind_s, day.d_wind_t );
    }
    node = node.nextSibling();
  }
}


/*!
    \fn CAfficheImage::weatherParsePart_n( const QDomElement &element, CWeatherDay &day )
 */
void CAfficheImage::weatherParsePart_n( const QDomElement &element, CWeatherDay &day )
{
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "icon" )
    {
      QDomNode childNode = node.firstChild();
      day.n_icon = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "t" )
    {
      QDomNode childNode = node.firstChild();
      day.n_t = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "ppcp" )
    {
      QDomNode childNode = node.firstChild();
      day.n_ppcp = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "hmid" )
    {
      QDomNode childNode = node.firstChild();
      day.n_hmid = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "wind" )
    {
      weatherParseWind( node.toElement(), day.n_wind_s, day.n_wind_t );
    }
    node = node.nextSibling();
  }
}


/*!
    \fn CAfficheImage::weatherParseWind( const QDomElement &element, QString &wind_s, QString &wind_t )
 */
void CAfficheImage::weatherParseWind( const QDomElement &element, QString &wind_s, QString &wind_t )
{
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "s" )
    {
      QDomNode childNode = node.firstChild();
      wind_s = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "t" )
    {
      QDomNode childNode = node.firstChild();
      wind_t = childNode.toText().data();
    }
    node = node.nextSibling();
  }
}


/*!
    \fn CAfficheImage::weatherParseBar( const QDomElement &element, QString &bar_r, QString &bar_d )
 */
void CAfficheImage::weatherParseBar( const QDomElement &element, QString &bar_r, QString &bar_d )
{
  QDomNode node = element.firstChild();
  while(!node.isNull())
  {
    if( node.toElement().tagName() == "r" )
    {
      QDomNode childNode = node.firstChild();
      bar_r = childNode.toText().data();
    }
    else if( node.toElement().tagName() == "d" )
    {
      QDomNode childNode = node.firstChild();
      bar_d = childNode.toText().data();
    }
    node = node.nextSibling();
  }
}     


/*!
    \fn CAfficheImage::weatherConvertSuns( QString &suns )
 */
void CAfficheImage::weatherConvertSuns( QString &suns )
{
  QString n =":";
  int index2point = suns.indexOf( n );
  QString gauche = suns.left( index2point );
  QString milieu = suns.mid( index2point, 3);
  int heure = gauche.toInt();
  heure += 12;
  QString h;
  h.setNum( heure );
  suns = h + milieu;
}


/*!
    \fn CAfficheImage::weatherConvertSunr( QString &sunr )
 */
void CAfficheImage::weatherConvertSunr( QString &sunr )
{
  QString n =":";
  int index2point = sunr.indexOf( n );
  QString gauche = sunr.left( index2point );
  QString milieu = sunr.mid( index2point, 3);
  sunr = gauche + milieu;
}
    



/*!
    \fn CAfficheImage::weatherSetDialogMeteo()
 */
void CAfficheImage::weatherSetDialogMeteo()
{
  QPixmap imgPNG;
  QString pathimg;
  
  CWeatherDlg weather( this );
  weather.set_loc_dnam( m_loc_dnam );
  
  weather.set_loc_sunr( m_loc_sunr );
  weather.set_loc_suns( m_loc_suns );
  
  QString cc_hmid = "H : " + m_cc_hmid + " %";
  weather.set_cc_hmid( cc_hmid );
  
  pathimg = m_pathData + "themes/Liquid/large_icons/" + m_cc_icon + ".png";
  imgPNG = QPixmap( pathimg );
  weather.set_cc_icon( imgPNG );

  weather.set_cc_t( m_cc_t );
  
  QString degree = tr(" °");
  QString cc_tmp = m_cc_tmp + degree + m_head_ut;
  weather.set_cc_tmp( cc_tmp );
  
  pathimg = m_pathData + "themes/wind_icons/liquid/medium/" + m_cc_wind_t + ".png";
  imgPNG = QPixmap( pathimg );
  weather.set_cc_wind_t( imgPNG );

  QString cc_wind_s = m_cc_wind_s + " " + m_head_us;
  weather.set_cc_wind_s( cc_wind_s );

/*  QString m_cc_bar_r;
  QString m_cc_bar_d;
  */

  
  
  
  weather.exec();

}

