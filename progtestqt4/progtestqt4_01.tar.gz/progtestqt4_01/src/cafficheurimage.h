/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jnd@localhost.localdomain   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef CAFFICHEURIMAGE_H
#define CAFFICHEURIMAGE_H

#include <QWidget>
#include <QPainter>

/**
	@author JND <jnd@localhost.localdomain>
*/
class CAfficheurImage : public QWidget
{
Q_OBJECT
public:
    CAfficheurImage(QWidget *parent = 0);
    CAfficheurImage(QWidget *parent = 0, int w = 0, int h = 0 );

    ~CAfficheurImage();

    QSize sizeHint() const;
    void afficheImage(const QImage &image);
    void definirImage( const QImage &image );

protected:
    void paintEvent(QPaintEvent *event);

private:
	QImage	m_image;
	int 	m_w;
	int	m_h;

};

#endif
