/***************************************************************************
 *   Copyright (C) 2007 by JND   *
 *   jnd@localhost.localdomain   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "cafficheurimage.h"

CAfficheurImage::CAfficheurImage(QWidget *parent)
 : QWidget(parent)
{
	setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
}

CAfficheurImage::CAfficheurImage( QWidget *parent, int w, int h )
 : QWidget(parent)
{
	m_w = w;
	m_h = h;
	setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
}

CAfficheurImage::~CAfficheurImage()
{
}


/*!
    \fn CAfficheurImage::paintEvent(QPaintEvent *event)
 */
void CAfficheurImage::paintEvent(QPaintEvent * /*event*/)
{

	QPainter painter( this );
	painter.drawImage( QPoint(0, 0), m_image );
}


/*!
    \fn CAfficheurImage::sizeHint() const
 */
QSize CAfficheurImage::sizeHint() const
{
	return QSize(m_w, m_h);
}


/*!
    \fn CAfficheurImage::afficheImage(const QImage &image)
 */
void CAfficheurImage::afficheImage(const QImage &image)
{
	m_image = image;
	update();
}


/*!
    \fn CAfficheurImage::definirImage( const QImage &image )
 */
void CAfficheurImage::definirImage( const QImage &image )
{
	m_image = image;
}
